/* =====================================================
   DJK Déménagement – Devis & Factures
   Tout fonctionne dans le navigateur, sans serveur.
   ===================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ---------- Données ---------- */
const DB_KEY = 'djk_gestion_v1';
const DEFAULTS = {
  settings: {
    company: 'DJK DEMENAGEMENT', address1: '55 RUE DES LILAS', address2: '95150 TAVERNY', city: 'TAVERNY',
    siret: '93948728600014', tva: 'FR91939487286', tel: '06 65 61 64 20', email: 'djkdemenagement@gmail.com',
    iban: 'FR29 3000 2006 2600 0000 6923 U32', bic: 'CRLYFRPP', watermark: true,
    tagline: "NATIONAL & INTERNATIONAL – PARTICULIERS – TRANSFERTS D'ENTREPRISES",
    legal: 'S.A.S.U au capital de 4 500 € - RCS PONTOISE 939 487 286 - APE 4942Z - TVA FR91939487286',
    nextDevis: 1, nextFacture: 68, nextLettre: 466, tvaRate: 20, acompte: 30, acompteEntreprise: true, taux: '0,3',
    garantieText: "GARANTIE DOMMAGE SANS FRANCHISE\nValeur globale entre 30 € et 30 000 €",
    logo: '', signature: '', stamp: ''
  },
  clients: [], devis: [], factures: [], lettres: [], events: [],
  pointage: { people: [], cells: {}, adj: {} }, compta: {}
};
let db = loadDB();
function loadDB() {
  try {
    const d = JSON.parse(localStorage.getItem(DB_KEY));
    if (d) return migrate({ ...structuredClone(DEFAULTS), ...d, settings: { ...DEFAULTS.settings, ...d.settings } });
  } catch (e) { /* première utilisation */ }
  return structuredClone(DEFAULTS);
}
// Corrige les anciennes données enregistrées dans le navigateur (ex : texte de garantie avec « HELVETIA »)
function migrate(d) {
  if (/helvetia/i.test(d.settings.garantieText || '')) d.settings.garantieText = DEFAULTS.settings.garantieText;
  d.lettres ||= [];
  if (/15 000/.test(d.settings.legal || '')) d.settings.legal = d.settings.legal.replace('15 000', '4 500');
  d.settings.bic ||= 'CRLYFRPP';
  d.pointage ||= { people: [], cells: {}, adj: {} }; d.pointage.people ||= []; d.pointage.cells ||= {}; d.pointage.adj ||= {};
  d.compta ||= {};
  return d;
}
function saveDB() {
  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); }
  catch (e) { toast("Enregistrement impossible : le navigateur refuse (mode privé ?)"); }
  scheduleBackup();   // copie interne + écriture dans le dossier de sauvegarde (voir plus bas)
}

/* ---------- Outils ---------- */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const iso = d => { const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000); return z.toISOString().slice(0, 10); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const frDate = s => s ? s.split('-').reverse().join('/') : '';
const frDay = s => s ? `${frDate(s)} (${new Date(s + 'T12:00').toLocaleDateString('fr-FR', { weekday: 'long' })})` : '';
const money = n => (Number(n) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
// Paiement sans TVA : taux 0 -> le prix saisi est le prix à payer (TTC = HT)
const rateOf = o => (o && o.sansTva) ? 0 : db.settings.tvaRate;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nl = s => esc(s).replace(/\n/g, '<br>');
const logoSrc = () => db.settings.logo || window.LOGO_DATA || 'assets/logo.png';
const cityOf = a => { const m = /\b\d{5}\s+([^,]+)/.exec(a || ''); return m ? m[1].trim() : (a || '').split(',').pop().trim(); };
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 3200); }
const year = d => (d || iso(new Date())).slice(0, 4);
const frNum = v => String(v ?? '').replace('.', ',');
const frLong = s => { if (!s) return ''; const t = new Date(s + 'T12:00').toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); return t.charAt(0).toUpperCase() + t.slice(1); };
const fmtSiret = s => { const d = String(s || '').replace(/\D/g, ''); return d.length === 14 ? `${d.slice(0, 3)} ${d.slice(3, 6)} ${d.slice(6, 9)} ${d.slice(9)}` : (s || ''); };

/* ---------- Recherche d'entreprise par SIRET (API publique de l'État, gratuite, sans clé) ---------- */
// Contrôle de Luhn : détecte une faute de frappe dans les 14 chiffres avant même d'appeler l'API
function luhn(n) {
  let sum = 0;
  [...n].reverse().forEach((c, i) => { let d = +c; if (i % 2) { d *= 2; if (d > 9) d -= 9; } sum += d; });
  return sum % 10 === 0;
}
async function lookupSiret(siret) {
  const r = await fetch(`https://recherche-entreprises.api.gouv.fr/search?q=${siret}&per_page=1`);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const j = await r.json();
  const e = j.results && j.results[0]; if (!e) return null;
  const et = [e.siege, ...(e.matching_etablissements || [])].filter(Boolean).find(x => x.siret === siret);
  if (!et) return null;
  let a = et.adresse || '';
  const tail = `${et.code_postal || ''} ${et.libelle_commune || ''}`.trim();
  if (tail && a.endsWith(tail)) a = a.slice(0, -tail.length).trim().replace(/,$/, '') + ', ' + tail;
  return { name: e.nom_raison_sociale || e.nom_complet || '', address: a, closed: et.etat_administratif === 'F' };
}
// Branche la recherche sur un formulaire : dès que le SIRET fait 14 chiffres (ou clic sur « Rechercher »)
function bindSiret(form, map) {
  const inp = form.elements[map.siret], btn = form.querySelector('[data-siret]'); let last = '';
  async function run(manual) {
    const s = inp.value.replace(/\D/g, '');
    if (s.length !== 14) { if (manual) toast('Le SIRET doit contenir 14 chiffres'); return; }
    if (!manual && s === last) return; last = s;
    if (!luhn(s)) { toast('SIRET invalide : vérifie les chiffres'); return; }
    toast("Recherche de l'entreprise…");
    try {
      const e = await lookupSiret(s);
      if (!e) { toast('Aucune entreprise trouvée pour ce SIRET'); return; }
      const n = form.elements[map.name];
      if (n && (!n.value.trim() || n.dataset.auto === n.value)) { n.value = e.name; n.dataset.auto = e.name; }
      const a = form.elements[map.address]; if (a && e.address) a.value = e.address;
      toast(e.closed ? `Attention : cet établissement est fermé (${e.name})` : `Entreprise trouvée : ${e.name}`);
    } catch (x) { toast('Recherche impossible (pas de connexion ?) : saisis les coordonnées à la main'); }
  }
  inp.addEventListener('input', () => run(false));
  if (btn) btn.onclick = () => run(true);
}

function get(o, p) { return p.split('.').reduce((a, k) => (a == null ? a : a[k]), o); }
function set(o, p, v) { const ks = p.split('.'); ks.slice(0, -1).forEach(k => { o = o[k] ??= {}; }); o[ks.at(-1)] = v; }
function fillForm(f, o) {
  [...f.elements].forEach(e => {
    if (!e.name) return;
    const v = get(o, e.name);
    if (e.type === 'checkbox') e.checked = !!v;
    else if (e.type === 'radio') e.checked = (v ?? 'N/C') === e.value;
    else e.value = v ?? '';
  });
}
function readForm(f) {
  const o = {};
  [...f.elements].forEach(e => {
    if (!e.name) return;
    if (e.type === 'radio') { if (e.checked) set(o, e.name, e.value); }
    else if (e.type === 'checkbox') set(o, e.name, e.checked);
    else set(o, e.name, e.value);
  });
  return o;
}

/* ---------- Navigation ---------- */
function show(v) {
  $$('.view').forEach(s => s.classList.toggle('hidden', s.id !== 'view-' + v));
  const parent = v.replace('Edit', '');
  $$('nav button').forEach(b => b.classList.toggle('active', b.dataset.view === parent));
  ({ devis: renderDevis, realises: renderRealises, factures: renderFactures, clients: renderClients, agenda: renderAgenda, settings: renderSettings, lettres: renderLettres, pointage: renderPointage, mois: renderMois }[parent] || (() => { }))();
  window.scrollTo(0, 0);
}
$$('nav button').forEach(b => b.onclick = () => show(b.dataset.view));
$$('[data-go]').forEach(b => b.onclick = () => show(b.dataset.go));

/* ---------- Clients ---------- */
function upsertClient(c) {
  if (!c.name) return;
  const k = c.name.trim().toLowerCase();
  let ex = db.clients.find(x => x.name.trim().toLowerCase() === k);
  if (!ex) { ex = { id: uid(), name: c.name.trim() }; db.clients.push(ex); }
  ['civ', 'tel', 'email', 'address', 'siret', 'type'].forEach(f => { if (c[f]) ex[f] = c[f]; });
}
const findClient = n => db.clients.find(x => x.name.trim().toLowerCase() === (n || '').trim().toLowerCase());
function refreshClientList() {
  $('#clientList').innerHTML = db.clients.map(c => `<option value="${esc(c.name)}">`).join('');
}
// Quand on tape un nom connu, le reste se remplit tout seul
function autoFillClient(form, map) {
  const nameEl = form.elements[map.name];
  nameEl.addEventListener('change', () => {
    const c = findClient(nameEl.value); if (!c) return;
    Object.entries(map).forEach(([k, field]) => {
      if (k === 'name') return;
      const el = form.elements[field]; if (el && c[k]) el.value = c[k];
    });
    form.dispatchEvent(new CustomEvent('autofilled'));
  });
}

/* =====================================================
   DEVIS
   ===================================================== */
const TRI = ['N/C', 'OUI', 'NON'];
const seg = n => `<div class="seg">${TRI.map(v => `<label><input type="radio" name="${n}" value="${v}"><span>${v}</span></label>`).join('')}</div>`;
function accHTML(p) {
  const row = (label, name, note) => `<div class="acc-row">${label}${seg(p + '.' + name)}${note ? `<input name="${p}.${name}Note" placeholder="${note}">` : ''}</div>`;
  return `
  <label>Date<input type="date" name="${p}.periode"></label>
  <label>Type de logement<select name="${p}.type"><option>Appartement</option><option>Maison</option><option>Bureau / Local</option><option>Garde-meuble</option><option>Autre</option></select></label>
  <label class="wide" style="position:relative">Adresse<input class="addr" name="${p}.adresse" placeholder="Tape l'adresse, choisis dans la liste"></label>
  <input type="hidden" name="${p}.lat"><input type="hidden" name="${p}.lon">
  <label>Étage<input name="${p}.etage" placeholder="ex : 3, RDC"></label>
  <label>Portage (m)<input name="${p}.portage" placeholder="N/C"></label>
  ${row('Ascenseur', 'ascenseur', 'précision (taille non connue…)')}
  ${row('Monte-meubles', 'monte')}
  ${row('Passage fenêtre', 'fenetre')}
  ${row('Transbordement', 'transbordement')}
  ${row('Autorisation de stationnement', 'stationnement', 'précision (obtenue par le client…)')}`;
}
function mmHTML() {
  const row = (label, name, note) => `<div class="acc-row">${label}${seg('mm.' + name)}${note ? `<input name="mm.${name}Note" placeholder="${note}">` : ''}</div>`;
  return `
  <label>Date de l'intervention<input type="date" name="mm.date"></label>
  <label>Heure<input type="time" name="mm.heure"></label>
  <label>Durée prévue<input name="mm.duree" placeholder="ex : 2 h, 2 jours"></label>
  <label>Date de fin (si plusieurs jours)<input type="date" name="mm.dateFin"></label>
  <label>Nature<select name="mm.nature"><option data-kind="mm">Montée de meubles</option><option data-kind="mm">Descente de meubles</option><option data-kind="mm">Montée et descente</option><option data-kind="mm">Autre</option><option data-kind="meuble">Démontage de meubles</option><option data-kind="meuble">Remontage de meubles</option><option data-kind="meuble">Démontage et remontage de meubles</option><option data-kind="meuble">Autre travail</option></select></label>
  <label class="wide" style="position:relative">Adresse de l'intervention<input class="addr" name="mm.adresse" placeholder="Tape l'adresse, choisis dans la liste"></label>
  <input type="hidden" name="mm.lat"><input type="hidden" name="mm.lon">
  <label>Type de logement<select name="mm.type"><option>Appartement</option><option>Maison</option><option>Bureau / Local</option><option>Autre</option></select></label>
  <label>Étage<input name="mm.etage" placeholder="ex : 5"></label>
  <label class="w2">De quoi il s'agit<textarea name="mm.objet" rows="3" placeholder="ex : montée d'un canapé 3 places et d'un frigo par la fenêtre"></textarea></label>
  ${row('Passage fenêtre / balcon', 'fenetre')}
  ${row('Autorisation de stationnement', 'stationnement', 'précision (obtenue par le client…)')}
  <label class="w2">Remarques<input name="mm.remarque" placeholder="facultatif"></label>`;
}
$('#mmBox').innerHTML = mmHTML();
$('#accFrom').innerHTML = accHTML('from');
$('#accTo').innerHTML = accHTML('to');

const emptyMm = () => ({ date: '', dateFin: '', heure: '', duree: '', nature: 'Montée de meubles', adresse: '', lat: '', lon: '', type: 'Appartement', etage: '', objet: '', fenetre: 'N/C', stationnement: 'N/C', stationnementNote: '', remarque: '' });
const emptyAcc = () => ({ periode: '', adresse: '', lat: '', lon: '', type: 'Appartement', etage: '', portage: '', ascenseur: 'N/C', ascenseurNote: '', monte: 'N/C', fenetre: 'N/C', transbordement: 'N/C', stationnement: 'N/C', stationnementNote: '' });
function devisNumber() { return `DEV-${year()}-${String(db.settings.nextDevis).padStart(3, '0')}`; }
function newDevis(p = {}) {
  const today = new Date();
  return {
    id: uid(), isNew: true, kind: 'demenagement', mm: emptyMm(), number: devisNumber(), date: iso(today), valid: iso(addDays(today, 30)),
    civ: 'M.', clientName: '', clientTel: '', clientEmail: '', clientAddress: '', clientSiret: '', paiement: 'acompte', sansTva: false,
    acMode: 'pct', acVal: '', acRecu: '', acRecuDate: '', acRecuMode: '',
    visited: false, visitedBy: '', visitedDate: iso(today),
    categorie: 'ÉCONOMIQUE', volume: '', voyage: 'NATIONAL', distance: '',
    annexes: { ...(db.settings.annexesDefault || {}) }, from: emptyAcc(), to: emptyAcc(), mobilier: '', particularite: '', prixHT: '', garantie: true, statut: 'En attente', ...p
  };
}
let curDevis = null;
function openDevis(id, prefill) {
  curDevis = id ? structuredClone(db.devis.find(x => x.id === id)) : newDevis(prefill);
  curDevis.kind ||= 'demenagement'; curDevis.paiement ||= 'acompte'; curDevis.acMode ||= 'pct'; curDevis.mm = { ...emptyMm(), ...curDevis.mm };
  fillForm($('#devisForm'), curDevis); toggleKind(); toggleCiv(false);
  $('#devisTitle').textContent = id ? `Devis ${curDevis.number}` : (curDevis.kind === 'mm' ? 'Nouveau devis monte-meuble' : curDevis.kind === 'meuble' ? 'Nouveau devis démontage / remontage' : 'Nouveau devis');
  refreshClientList(); updateDevisTotals(); show('devisEdit');
}
function toggleKind() {
  const F = $('#devisForm'), k = F.elements.kind.value;
  $$('#devisForm [data-kind]').forEach(e => { if (e.tagName !== 'OPTION') e.classList.toggle('hidden', !e.dataset.kind.split(' ').includes(k)); });
  const nat = F.elements['mm.nature'];
  [...nat.options].forEach(o => { o.hidden = o.disabled = o.dataset.kind !== (k === 'meuble' ? 'meuble' : 'mm'); });
  if (!nat.selectedOptions.length || nat.selectedOptions[0].disabled) nat.value = [...nat.options].find(o => !o.disabled).value;
  $('#mmTitle').textContent = k === 'meuble' ? 'Démontage / remontage de meubles' : 'Monte-meuble';
}
$('#devisForm').elements.kind.onchange = toggleKind;
function calcTotals(ht, rate, acomptePct, fixed) {
  ht = r2(ht); const tva = r2(ht * rate / 100), ttc = r2(ht + tva);
  let ac = r2(ttc * acomptePct / 100);
  if (fixed != null) ac = Math.min(r2(fixed), ttc);   // acompte en montant fixe (ex : 380 € sur 1 380 €)
  return { ht, tva, ttc, ac, solde: r2(ttc - ac) };
}
// Entreprise : on peut ne pas demander d'acompte (règlement en une fois le jour de la prestation)
const payMode = d => (d.civ === 'Société' && d.paiement === 'unique') ? 'unique' : 'acompte';
// Acompte demandé : soit un pourcentage (30 % par défaut, modifiable), soit un montant fixe en euros
const acNum = d => { const v = String(d.acVal ?? '').trim().replace(',', '.'); return v !== '' && !isNaN(Number(v)) ? Number(v) : null; };
const acFixed = d => (payMode(d) !== 'unique' && d.acMode === 'fixe') ? acNum(d) : null;
const acPct = d => payMode(d) === 'unique' ? 0 : ((d.acMode !== 'fixe' && acNum(d) != null) ? acNum(d) : db.settings.acompte);
const docTotals = d => calcTotals(d.prixHT, rateOf(d), acPct(d), acFixed(d));
const acLabel = d => acFixed(d) != null ? 'Acompte à la commande' : `${frNum(acPct(d))} % à la commande`;
const acRecu = d => Number(String(d.acRecu ?? '').replace(',', '.')) || 0;
function toggleCiv(changed) {
  const f = $('#devisForm'), soc = f.elements.civ.value === 'Société';
  $('#dSiretWrap').classList.toggle('hidden', !soc); $('#dPayWrap').classList.toggle('hidden', !soc);
  if (changed) f.elements.paiement.value = soc && db.settings.acompteEntreprise === false ? 'unique' : 'acompte';
  updateDevisTotals();
}
$('#devisForm').elements.civ.onchange = () => toggleCiv(true);
$('#devisForm').addEventListener('autofilled', () => toggleCiv(true));
function updateDevisTotals() {
  const f = $('#devisForm'); const d = readForm(f);
  const t = docTotals(d), recu = acRecu(d), unique = payMode(d) === 'unique';
  $('#dAcWrap').classList.toggle('hidden', unique); $('#dAcValWrap').classList.toggle('hidden', unique);
  $('#dAcValLbl').textContent = d.acMode === 'fixe' ? 'Montant de l\'acompte (€)' : 'Pourcentage (%)';
  $('#dTotals').innerHTML = (d.sansTva
    ? `<div class="big"><span>Prix net à payer (sans TVA)</span><span>${money(t.ttc)}</span></div>`
    : `<div><span>Prix HT</span><span>${money(t.ht)}</span></div>
    <div><span>TVA ${db.settings.tvaRate} %</span><span>${money(t.tva)}</span></div>
    <div class="big"><span>Prix TTC</span><span>${money(t.ttc)}</span></div>`) + `
    ${payMode(d) === 'unique'
      ? `<div><span>Aucun acompte : règlement en une fois le jour de la prestation</span><span>${money(t.ttc)}</span></div>`
      : `<div><span>${acLabel(d)}</span><span>${money(t.ac)}</span></div>
    <div><span>Solde à la livraison</span><span>${money(t.solde)}</span></div>`}`
    + (recu > 0 ? `<div class="big"><span>Acompte déjà reçu</span><span>${money(recu)}</span></div><div><span>Reste à encaisser</span><span>${money(r2(t.ttc - recu))}</span></div>` : '');
}
$('#dAcFill').onclick = () => {
  const F = $('#devisForm').elements, t = docTotals(readForm($('#devisForm')));
  F.acRecu.value = t.ac; if (!F.acRecuDate.value) F.acRecuDate.value = iso(new Date()); updateDevisTotals();
};
['input', 'change'].forEach(ev => $('#devisForm').addEventListener(ev, e => { if (['prixHT', 'paiement', 'sansTva', 'acMode', 'acVal', 'acRecu'].includes(e.target.name)) updateDevisTotals(); }));
autoFillClient($('#devisForm'), { name: 'clientName', civ: 'civ', tel: 'clientTel', email: 'clientEmail', address: 'clientAddress', siret: 'clientSiret' });

function collectDevis() {
  const d = { ...curDevis, ...readForm($('#devisForm')) };
  d.from = { ...emptyAcc(), ...d.from }; d.to = { ...emptyAcc(), ...d.to }; d.mm = { ...emptyMm(), ...d.mm };
  return d;
}
function saveDevis(silent) {
  const d = collectDevis();
  if (!d.clientName.trim()) { toast('Indique le nom du client'); return null; }
  const wasNew = d.isNew; delete d.isNew;
  db.settings.annexesDefault = { ...(d.annexes || {}) };   // on garde le dernier choix de documents à joindre
  const prev = db.devis.find(x => x.id === d.id);
  if (wasNew) { db.devis.push(d); db.settings.nextDevis++; }
  else db.devis[db.devis.indexOf(prev)] = d;
  upsertClient({ name: d.clientName, civ: d.civ, tel: d.clientTel, email: d.clientEmail, address: d.clientAddress, siret: d.clientSiret, type: d.civ === 'Société' ? 'entreprise' : '' });
  if (d.statut === 'Accepté' && (!prev || prev.statut !== 'Accepté')) addEventsFromDevis(d);
  saveDB(); curDevis = d; $('#devisTitle').textContent = `Devis ${d.number}`;
  if (!silent) toast('Devis enregistré');
  return d;
}
$('#dSave').onclick = () => saveDevis();
$('#newDevis').onclick = () => openDevis();
$('#newDevisMm').onclick = () => openDevis(null, { kind: 'mm' });
$('#newDevisMb').onclick = () => openDevis(null, { kind: 'meuble', mm: { ...emptyMm(), nature: 'Démontage et remontage de meubles' } });
const isMb = d => d.kind === 'meuble';
const isMm = d => d.kind === 'mm' || d.kind === 'meuble';   // une seule adresse : monte-meuble ou démontage / remontage
const route = d => isMm(d) ? `${isMb(d) ? 'Démontage / remontage' : 'Monte-meuble'} – ${cityOf(d.mm?.adresse)}` : `${cityOf(d.from.adresse)} → ${cityOf(d.to.adresse)}`;

/* Statut de l'acompte dans la liste */
function acCell(d) {
  if (d.statut === 'Refusé') return '–';
  if (payMode(d) === 'unique') return '<span class="hint">aucun</span>';
  const r = acRecu(d);
  return r > 0 ? `<span class="ok">reçu ${money(r)}</span>` : `<span class="warn">à recevoir ${money(docTotals(d).ac)}</span>`;
}
// Bouton « Acompte reçu » : on tape le montant réellement payé (peut être différent des 30 %)
function quickAcompte(d) {
  const v = prompt(`Acompte reçu de ${d.clientName} (en €). Mets 0 pour dire « pas encore reçu ».`, String(acRecu(d) || docTotals(d).ac).replace('.', ','));
  if (v === null) return;
  const n = Number(String(v).replace(/\s/g, '').replace(',', '.'));
  if (isNaN(n) || n < 0) { toast('Montant invalide'); return; }
  if (n > 0) { d.acRecu = r2(n); d.acRecuDate ||= iso(new Date()); } else { d.acRecu = ''; d.acRecuDate = ''; d.acRecuMode = ''; }
  saveDB(); renderDevis(); toast(n > 0 ? `Acompte de ${money(n)} enregistré` : 'Acompte remis à « pas encore reçu »');
}

/* ---------- Message à copier-coller pour les chauffeurs ---------- */
function pointTxt(label, a) {
  const bits = [a.type, `étage ${a.etage || 'N/C'}`, `ascenseur : ${a.ascenseur || 'N/C'}`];
  if (a.portage) bits.push(`portage ${a.portage} m`);
  if (a.monte === 'OUI') bits.push('monte-meuble : OUI');
  if (a.stationnement === 'NON') bits.push('pas d\'autorisation de stationnement');
  return `${label} : ${a.adresse || 'N/C'}\n   (${bits.join(', ')})`;
}
function driverText(d) {
  const t = docTotals(d), recu = acRecu(d), L = [];
  const who = d.civ === 'Société' ? d.clientName : `${d.civ} ${d.clientName}`;
  if (isMm(d)) {
    const m = d.mm;
    L.push(`${isMb(d) ? 'DÉMONTAGE / REMONTAGE DE MEUBLES' : 'MONTE-MEUBLE'} – ${who}`, `Le ${frDay(m.date) || 'date à confirmer'}${m.heure ? ' à ' + m.heure : ''}${m.duree ? ' (durée prévue : ' + m.duree + ')' : ''}`, '',
      `Adresse : ${m.adresse || 'N/C'}`, `(${m.type}, étage ${m.etage || 'N/C'}, ${m.nature.toLowerCase()})`);
    if (m.dateFin && m.dateFin !== m.date) L.push(`Jusqu’au ${frDay(m.dateFin)}`);
    if (m.objet) L.push(`${isMb(d) ? 'Meubles concernés' : 'À monter / descendre'} : ${m.objet}`);
    if (m.fenetre === 'OUI') L.push('Passage par fenêtre / balcon : OUI');
  } else {
    const same = d.from.periode && d.from.periode === d.to.periode;
    L.push(`DÉMÉNAGEMENT – ${who}`);
    if (same) L.push(`Le ${frDay(d.from.periode)} (chargement et livraison)`);
    else L.push(`Chargement : ${frDay(d.from.periode) || 'à confirmer'}`, `Livraison : ${frDay(d.to.periode) || 'à confirmer'}`);
    L.push('', pointTxt('DÉPART', d.from), pointTxt('ARRIVÉE', d.to), '');
    L.push(`Volume : ${d.volume ? frNum(d.volume) + ' m³' : 'N/C'} – Distance : ${d.distance ? frNum(d.distance) + ' km' : 'N/C'}`);
    if (d.particularite) L.push(`Particularité : ${d.particularite.replace(/\n+/g, ' / ')}`);
  }
  L.push('', `Tél : ${d.clientTel || 'N/C'}`, `Email : ${d.clientEmail || 'N/C'}`, '');
  L.push(`PRIX : ${money(t.ttc)}${d.sansTva ? ' (sans TVA)' : ' TTC'}`);
  if (payMode(d) === 'unique') L.push('Pas d\'acompte : tout est à encaisser le jour de la prestation', `RESTE À ENCAISSER : ${money(t.ttc)}`);
  else if (recu > 0) L.push(`Acompte reçu : ${money(recu)}${d.acRecuMode ? ' (' + d.acRecuMode.toLowerCase() + ')' : ''}`, `RESTE À ENCAISSER : ${money(r2(t.ttc - recu))}`);
  else L.push(`Acompte demandé : ${money(t.ac)} (pas encore reçu)`, `RESTE À ENCAISSER : ${money(t.solde)} (une fois l'acompte reçu)`);
  return L.join('\n');
}
function showDriverMsg(d) {
  const el = document.createElement('div'); el.className = 'dlg';
  el.innerHTML = `<div class="dlg-box" style="max-width:660px"><h3>Message pour les chauffeurs</h3>
    <p class="hint">Tu peux modifier le texte avant de le copier.</p>
    <textarea rows="18"></textarea>
    <div class="dlg-btns"><button class="btn primary" data-c="copy">Copier</button><button class="btn" data-c="close">Fermer</button></div></div>`;
  const ta = $('textarea', el); ta.value = driverText(d);
  el.onclick = async e => {
    const c = e.target.dataset.c || (e.target === el ? 'close' : null); if (!c) return;
    if (c === 'close') { el.remove(); return; }
    try { await navigator.clipboard.writeText(ta.value); } catch (x) { ta.select(); document.execCommand('copy'); }
    toast('Message copié : colle-le dans WhatsApp / SMS');
  };
  document.body.appendChild(el);
}
$('#dDriver').onclick = () => { const d = collectDevis(); if (!d.clientName.trim()) { toast('Indique le nom du client'); return; } showDriverMsg(d); };

/* ---------- Déménagements réalisés : on range le devis au lieu de le supprimer ---------- */
const doneDate = d => isMm(d) ? (d.mm?.date || '') : (d.to?.periode || d.from?.periode || '');
const isPassed = d => d.statut === 'Accepté' && doneDate(d) && doneDate(d) < iso(new Date());
function setRealise(d, yes) {
  d.statut = yes ? 'Réalisé' : 'Accepté'; saveDB();
  toast(yes ? `${d.clientName} : déplacé dans « Réalisés »` : `${d.clientName} : remis dans les devis en cours`);
  show(yes ? 'devis' : 'realises');
}
function renderRealises() {
  const q = $('#qDone').value.trim().toLowerCase();
  const rows = db.devis.filter(d => d.statut === 'Réalisé' && (d.clientName + d.number + route(d)).toLowerCase().includes(q))
    .sort((a, b) => doneDate(b).localeCompare(doneDate(a)));
  const tot = rows.reduce((s, d) => s + docTotals(d).ttc, 0);
  $('#doneSum').textContent = rows.length ? `${rows.length} réalisé${rows.length > 1 ? 's' : ''} – total ${money(tot)} TTC` : '';
  $('#doneTable').innerHTML = rows.length ? `
    <tr><th>Fait le</th><th>Client</th><th>Prestation</th><th class="r">TTC</th><th>Facture</th><th></th></tr>
    ${rows.map(d => {
      const fs = factsFor(d.clientName, d.id);
      return `<tr><td>${frDate(doneDate(d))}</td><td>${esc(d.clientName)}<br><span class="hint">${esc(d.number)}</span></td><td>${esc(route(d))}</td>
      <td class="r">${money(docTotals(d).ttc)}</td>
      <td>${fs.length ? `<span class="${fs.every(f => f.statut === 'Payée') ? 'ok' : 'warn'}">${fs.map(f => `n° ${esc(f.number)} ${f.statut === 'Payée' ? '(payée)' : '(à payer)'}`).join('<br>')}</span>` : '<span class="warn">à faire</span>'}</td>
      <td class="r"><button class="btn small" data-o="${d.id}">Ouvrir</button><button class="btn small" data-p="${d.id}">PDF</button><button class="btn small" data-f="${d.id}">Facturer</button><button class="btn small danger" data-u="${d.id}">Remettre en cours</button></td></tr>`;
    }).join('')}` : `<tr><td class="empty">Aucun déménagement réalisé pour l'instant. Dans la liste des devis, clique sur « Marquer réalisé » quand c'est fait.</td></tr>`;
  const T = $('#doneTable');
  $$('[data-o]', T).forEach(b => b.onclick = () => openDevis(b.dataset.o));
  $$('[data-p]', T).forEach(b => b.onclick = () => pdf('devis', db.devis.find(x => x.id === b.dataset.p)));
  $$('[data-f]', T).forEach(b => b.onclick = () => factureFromDevis(db.devis.find(x => x.id === b.dataset.f)));
  $$('[data-u]', T).forEach(b => b.onclick = () => setRealise(db.devis.find(x => x.id === b.dataset.u), false));
}
$('#qDone').oninput = renderRealises;

/* ---------- Email à envoyer au client avec le devis ---------- */
function mailText(d) {
  const s = db.settings, t = docTotals(d), pro = d.civ === 'Société', L = [];
  const hello = d.civ === 'Mme' ? 'Bonjour Madame,' : pro ? 'Madame, Monsieur,' : 'Bonjour Monsieur,';
  const low = x => frLong(x).toLowerCase();
  let quand;
  if (isMm(d)) {
    const m = d.mm;
    quand = `${isMb(d) ? `pour votre intervention (${m.nature.toLowerCase()})` : 'pour votre intervention avec monte-meuble'}${m.date ? ' prévue le ' + low(m.date) + (m.dateFin && m.dateFin !== m.date ? ' au ' + low(m.dateFin) : '') + (m.heure ? ' à ' + m.heure : '') : ''}`;
  } else {
    const a = d.from.periode, b = d.to.periode;
    quand = `pour votre déménagement de ${cityOf(d.from.adresse) || '…'} vers ${cityOf(d.to.adresse) || '…'}`
      + (a && b && a !== b ? `, avec chargement le ${low(a)} et livraison le ${low(b)}` : (a || b) ? `, prévu le ${low(a || b)}` : '');
  }
  const prix = d.sansTva ? `${money(t.ttc)} net (TVA non applicable)` : pro ? `${money(t.ht)} HT, soit ${money(t.ttc)} TTC` : `${money(t.ttc)} TTC`;
  const ann = annexList(d).map(x => x[0]);
  const annTxt = ann.length ? `Vous trouverez aussi, dans le même fichier : ${ann.join(', ')}.` : '';
  if (pro) {
    L.push(hello, '', `Suite à votre demande, veuillez trouver ci-joint notre devis n° ${d.number} ${quand}.`, '', `Montant : ${prix}, valable jusqu’au ${frDate(d.valid)}.`);
    if (annTxt) L.push('', annTxt);
    L.push('', 'Pour valider la prestation, il vous suffit de nous retourner le devis daté et signé, avec la mention « Bon pour accord » (et votre bon de commande si votre organisation en utilise un).', '', 'Nous restons à votre entière disposition pour tout complément d’information.', '', 'Bien cordialement,');
  } else {
    L.push(hello, '', `Un grand merci pour votre confiance et pour le temps que vous nous avez accordé. Comme convenu, vous trouverez ci-joint votre devis n° ${d.number} ${quand}.`, '', `En résumé : ${prix}, valable jusqu’au ${frDate(d.valid)}.`);
    if (annTxt) L.push('', annTxt);
    L.push('', 'Si tout vous convient, il vous suffit de nous retourner le devis daté et signé, avec la mention manuscrite « Bon pour accord » : nous réserverons alors votre date avec plaisir.', '', 'Et si vous avez la moindre question, ou si vous souhaitez ajuster quelque chose, n’hésitez pas à me répondre ou à m’appeler : je suis là pour vous aider.', '', 'Belle journée à vous,', 'Cordialement,');
  }
  L.push('DJK Déménagement', `Tél : ${s.tel}`, s.email);
  return { subject: `Votre devis ${isMb(d) ? 'de démontage / remontage de meubles' : isMm(d) ? 'monte-meuble' : 'de déménagement'} ${s.company} – n° ${d.number}`, body: L.join('\n') };
}
// Fenêtre d'email générique (devis ET factures) : destinataire, objet, texte modifiables
function openMailDialog({ to, subject, body, pdf: makePdf }) {
  const el = document.createElement('div'); el.className = 'dlg';
  el.innerHTML = `<div class="dlg-box" style="max-width:680px"><h3>Email au client</h3>
    <p class="hint">Modifie le texte si besoin. Le PDF ne peut pas se joindre tout seul : télécharge-le, puis joins-le à ton mail.</p>
    <label>À<input data-f="to" style="width:100%;box-sizing:border-box" placeholder="email du client"></label>
    <label>Objet<input data-f="subj" style="width:100%;box-sizing:border-box"></label>
    <textarea rows="16"></textarea>
    <div class="dlg-btns"><button class="btn primary" data-c="open">Ouvrir dans ma messagerie</button><button class="btn" data-c="copy">Copier le texte</button><button class="btn" data-c="pdf">Télécharger le PDF</button><button class="btn" data-c="close">Fermer</button></div></div>`;
  const ta = $('textarea', el), toI = $('[data-f=to]', el), subj = $('[data-f=subj]', el);
  ta.value = body; subj.value = subject; toI.value = to || '';
  el.onclick = async e => {
    const c = e.target.dataset.c || (e.target === el ? 'close' : null); if (!c) return;
    if (c === 'close') { el.remove(); return; }
    if (c === 'pdf') { makePdf(); return; }
    if (c === 'open') { location.href = `mailto:${encodeURIComponent(toI.value.trim())}?subject=${encodeURIComponent(subj.value)}&body=${encodeURIComponent(ta.value)}`; return; }
    try { await navigator.clipboard.writeText(ta.value); } catch (x) { ta.select(); document.execCommand('copy'); }
    toast('Texte copié');
  };
  document.body.appendChild(el);
}
const showMailMsg = d => openMailDialog({ to: d.clientEmail, ...mailText(d), pdf: () => pdf('devis', d) });
// Email d'une facture : différent pour un particulier et pour une entreprise ; jamais de RIB ni de montant à payer dans le texte
function factMailText(f) {
  const s = db.settings, c = findClient(f.clientName), dv = db.devis.find(x => x.id === f.devisId), civ = c?.civ || dv?.civ;
  const pro = f.type === 'entreprise' || civ === 'Société', L = [];
  const hello = pro ? 'Madame, Monsieur,' : civ === 'Mme' ? 'Bonjour Madame,' : 'Bonjour Monsieur,';
  const ref = f.devisRef || dv?.number, k = f.kind || 'complete';
  const what = pro ? { complete: 'la facture', acompte: 'la facture d’acompte', solde: 'la facture de solde' }[k] : { complete: 'votre facture', acompte: 'votre facture d’acompte', solde: 'votre facture de solde' }[k];
  L.push(hello, '');
  if (pro) {
    const suite = f.bonCommande ? ` établie suite à votre bon de commande n° ${f.bonCommande}${f.bonCommandeDate ? ' du ' + frDate(f.bonCommandeDate) : ''}` : ref ? ` établie suite à notre devis n° ${ref}` : '';
    L.push(`Veuillez trouver ci-joint ${what} n° ${f.number} du ${frDate(f.date)}${suite}${f.codeEngagement ? ' (code engagement : ' + f.codeEngagement + ')' : ''}.`);
    if (f.statut === 'Payée') L.push('', 'Cette facture est acquittée.');
    L.push('', 'Nous vous remercions de votre confiance et restons à votre disposition pour tout renseignement complémentaire.', '', 'Bien cordialement,');
  } else {
    L.push(`Nous vous remercions encore pour la confiance que vous nous avez accordée. Vous trouverez ci-joint ${what} n° ${f.number} du ${frDate(f.date)}${ref ? ' (suite à notre devis n° ' + ref + ')' : ''}.`);
    if (f.statut === 'Payée') L.push('', 'Elle est acquittée : il n’y a rien de plus à faire de votre côté.');
    L.push('', 'Nous espérons que tout s’est bien passé pour vous. Si vous avez la moindre question ou remarque, n’hésitez pas à nous le dire : votre avis compte beaucoup pour nous.', '', 'Très belle journée à vous,', 'Cordialement,');
  }
  L.push('DJK Déménagement', `Tél : ${s.tel}`, s.email);
  return { subject: pro ? `Facture n° ${f.number} – ${s.company}${f.bonCommande ? ' – BC ' + f.bonCommande : ''}` : `Votre facture n° ${f.number} – ${s.company}`, body: L.join('\n') };
}
const showFactMail = f => openMailDialog({ to: findClient(f.clientName)?.email || db.devis.find(x => x.id === f.devisId)?.clientEmail || '', ...factMailText(f),
  pdf: () => { const x = f.isNew ? saveFact(true) : f; if (x) pdf('facture', x); } });
$('#dMail').onclick = () => { const d = collectDevis(); if (!d.clientName.trim()) { toast('Indique le nom du client'); return; } showMailMsg(d); };

/* Liste des devis */
function renderDevis() {
  const q = $('#qDevis').value.trim().toLowerCase();
  const rows = db.devis.filter(d => d.statut !== 'Réalisé' && (d.clientName + d.number).toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date) || b.number.localeCompare(a.number));
  const late = db.devis.filter(isPassed);
  $('#doneHint').innerHTML = late.length ? `<b>${late.length} déménagement${late.length > 1 ? 's' : ''} accepté${late.length > 1 ? 's' : ''} dont la date est passée</b> (${late.map(d => esc(d.clientName)).join(', ')}) : clique sur « Marquer réalisé » pour le ranger dans l'onglet Réalisés.` : '';
  $('#doneHint').classList.toggle('hidden', !late.length);
  $('#devisTable').innerHTML = rows.length ? `
    <tr><th>N°</th><th>Date</th><th>Client</th><th>Prestation</th><th class="r">TTC</th><th>Acompte</th><th>Statut</th><th></th></tr>
    ${rows.map(d => `<tr>
      <td>${esc(d.number)}</td><td>${frDate(d.date)}</td><td>${esc(d.clientName)}</td>
      <td>${esc(route(d))}</td>
      <td class="r">${money(calcTotals(d.prixHT, rateOf(d), 0).ttc)}</td>
      <td>${acCell(d)}</td>
      <td><select data-st="${d.id}">${['En attente', 'Accepté', 'Réalisé', 'Refusé'].map(s => `<option ${s === d.statut ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td class="r"><button class="btn small" data-o="${d.id}">Ouvrir</button><button class="btn small" data-p="${d.id}">PDF</button><button class="btn small" data-ml="${d.id}">Email</button><button class="btn small" data-m="${d.id}">Chauffeurs</button>${d.statut === 'Accepté' ? `<button class="btn small ${isPassed(d) ? 'primary' : ''}" data-r="${d.id}">Marquer réalisé</button>` : ''}<button class="btn small" data-a="${d.id}">Acompte reçu</button>${isMm(d) ? '' : `<button class="btn small" data-l="${d.id}">Lettre de voiture</button>`}<button class="btn small" data-f="${d.id}">Facturer</button><button class="btn small danger" data-x="${d.id}">Suppr.</button></td>
    </tr>`).join('')}` : `<tr><td class="empty">Aucun devis pour l'instant. Clique sur « Nouveau devis ».</td></tr>`;
  $$('[data-o]', $('#devisTable')).forEach(b => b.onclick = () => openDevis(b.dataset.o));
  $$('[data-p]', $('#devisTable')).forEach(b => b.onclick = () => pdf('devis', db.devis.find(x => x.id === b.dataset.p)));
  $$('[data-ml]', $('#devisTable')).forEach(b => b.onclick = () => showMailMsg(db.devis.find(x => x.id === b.dataset.ml)));
  $$('[data-r]', $('#devisTable')).forEach(b => b.onclick = () => setRealise(db.devis.find(x => x.id === b.dataset.r), true));
  $$('[data-m]', $('#devisTable')).forEach(b => b.onclick = () => showDriverMsg(db.devis.find(x => x.id === b.dataset.m)));
  $$('[data-a]', $('#devisTable')).forEach(b => b.onclick = () => quickAcompte(db.devis.find(x => x.id === b.dataset.a)));
  $$('[data-l]', $('#devisTable')).forEach(b => b.onclick = () => lettreFromDevis(db.devis.find(x => x.id === b.dataset.l)));
  $$('[data-f]', $('#devisTable')).forEach(b => b.onclick = () => factureFromDevis(db.devis.find(x => x.id === b.dataset.f)));
  $$('[data-x]', $('#devisTable')).forEach(b => b.onclick = () => { if (confirm('Supprimer ce devis ?')) { db.devis = db.devis.filter(x => x.id !== b.dataset.x); saveDB(); renderDevis(); } });
  $$('[data-st]', $('#devisTable')).forEach(s => s.onchange = () => {
    const d = db.devis.find(x => x.id === s.dataset.st); const was = d.statut; d.statut = s.value;
    if (s.value === 'Accepté' && was !== 'Accepté') addEventsFromDevis(d);
    saveDB(); toast(`Devis ${d.number} : ${d.statut}`); if (d.statut === 'Réalisé') renderDevis();
  });
}
$('#qDevis').oninput = renderDevis;

/* ---------- Adresses (autocomplétion) et kilométrage ---------- */
async function geocode(q) {
  const r = await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=fr&q=${encodeURIComponent(q)}`);
  const j = await r.json(); return j[0] ? { lat: j[0].lat, lon: j[0].lon } : null;
}
async function calcDistance(f, silent) {
  const g = n => f.elements[n]; const pts = [];
  try {
    for (const p of ['from', 'to']) {
      let la = g(p + '.lat').value, lo = g(p + '.lon').value;
      if (!la) {
        const a = g(p + '.adresse').value.trim();
        if (!a) { if (!silent) toast('Renseigne les adresses de chargement et de livraison'); return; }
        const c = await geocode(a);
        if (!c) { if (!silent) toast('Adresse introuvable : ' + a); return; }
        la = c.lat; lo = c.lon; g(p + '.lat').value = la; g(p + '.lon').value = lo;
      }
      pts.push(lo + ',' + la);
    }
    const r = await fetch(`https://router.project-osrm.org/route/v1/driving/${pts.join(';')}?overview=false`);
    const j = await r.json();
    if (j.routes && j.routes[0]) { const km = j.routes[0].distance / 1000; g('distance').value = km < 10 ? Math.round(km * 10) / 10 : Math.round(km); if (!silent) toast('Distance calculée'); }
    else if (!silent) toast('Itinéraire introuvable');
  } catch (e) { if (!silent) toast('Pas de connexion : saisis la distance à la main'); }
}
$('#btnKm').onclick = () => calcDistance($('#devisForm'), false);

function attachAddr(input) {
  const wrap = input.parentElement; wrap.style.position = 'relative';
  const box = document.createElement('div'); box.className = 'ac hidden'; wrap.appendChild(box);
  const base = input.name.replace(/adresse$/, '');
  const latEl = input.form.elements[base + 'lat'], lonEl = input.form.elements[base + 'lon'];
  let t;
  input.addEventListener('input', () => {
    if (latEl) { latEl.value = ''; lonEl.value = ''; }
    clearTimeout(t);
    const q = input.value.trim(); if (q.length < 4) { box.classList.add('hidden'); return; }
    t = setTimeout(async () => {
      try {
        const r = await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=5&accept-language=fr&q=${encodeURIComponent(q)}`);
        const j = await r.json();
        box.innerHTML = '';
        j.forEach(x => {
          const a = x.address || {};
          const rue = [a.house_number, a.road].filter(Boolean).join(' ');
          const ville = [a.postcode, a.city || a.town || a.village || a.municipality].filter(Boolean).join(' ');
          const label = (rue && ville) ? `${rue}, ${ville}` : x.display_name;
          const d = document.createElement('div'); d.textContent = label;
          d.onclick = () => {
            input.value = label; box.classList.add('hidden');
            if (latEl) { latEl.value = x.lat; lonEl.value = x.lon; }
            if (base === 'from.' || base === 'to.') { const f = input.form; if (f.elements['from.adresse'].value && f.elements['to.adresse'].value) calcDistance(f, true); }
          };
          box.appendChild(d);
        });
        box.classList.toggle('hidden', !j.length);
      } catch (e) { box.classList.add('hidden'); }
    }, 500);
  });
  input.addEventListener('blur', () => setTimeout(() => box.classList.add('hidden'), 200));
}
$$('input.addr').forEach(attachAddr);

/* ---------- Agenda auto depuis un devis accepté ---------- */
function eventTitle(d, side) {
  const vol = d.volume ? ` – ${d.volume} m³` : '';
  return `${side === 'from' ? 'Chargement' : 'Livraison'} : ${d.clientName}${vol} – ${cityOf(d.from.adresse)} → ${cityOf(d.to.adresse)}`;
}
function addEventsFromDevis(d) {
  db.events = db.events.filter(e => !(e.devisId === d.id && e.auto));
  if (isMm(d)) {
    const m = d.mm;
    if (m.date) {
      const last = m.dateFin && m.dateFin > m.date ? m.dateFin : m.date;
      for (let x = m.date, n = 0; x <= last && n < 60; x = iso(addDays(new Date(x + 'T12:00'), 1)), n++)
        db.events.push({ id: uid(), date: x, devisId: d.id, auto: true,
          title: `${isMb(d) ? 'Démontage/remontage' : 'Monte-meuble'}${m.heure ? ' ' + m.heure : ''} : ${d.clientName} – ${m.nature}${m.etage ? ' – étage ' + m.etage : ''} – ${cityOf(m.adresse)}` });
      toast("Date ajoutée à l'agenda");
    } else toast("Devis accepté : renseigne la date pour l'agenda");
    return;
  }
  const ds = [['from', d.from.periode], ['to', d.to.periode]].filter(x => x[1]);
  if (ds.length === 2 && ds[0][1] === ds[1][1]) ds.pop();
  ds.forEach(([side, date]) => db.events.push({ id: uid(), date, title: eventTitle(d, side), devisId: d.id, auto: true }));
  if (ds.length) toast('Dates ajoutées à l\'agenda'); else toast('Devis accepté : renseigne les dates pour l\'agenda');
}

/* =====================================================
   FACTURES
   ===================================================== */
let curFact = null;
const factNum = f => parseInt(String(f.number), 10) || 0;
// Numéro suivant = plus grand numéro de facture existant + 1 (ou le n° de départ des Réglages s'il n'y a aucune facture).
// Ouvrir « Nouvelle facture » ne consomme rien : le numéro ne bouge que quand on enregistre, et un numéro supprimé redevient libre.
const nextFactNum = () => db.factures.length ? Math.max(...db.factures.map(factNum)) + 1 : db.settings.nextFacture;
const factNumber = () => `${nextFactNum()}-${year()}`;
const kindLabel = f => ({ complete: 'complète', acompte: 'acompte', solde: 'solde' }[f.kind || 'complete'] || 'complète');
const normName = s => String(s || '').trim().toLowerCase();

// Factures déjà faites pour ce client : même devis, ou même nom si la facture n'est liée à aucun devis (la facture en cours est exclue)
function factsFor(name, devisId, exceptId) {
  const n = normName(name);
  return db.factures.filter(f => f.id !== exceptId && (devisId
    ? (f.devisId === devisId || (!f.devisId && n && normName(f.clientName) === n))
    : (n && normName(f.clientName) === n))).sort((a, b) => factNum(a) - factNum(b));
}
const devisFor = (name, devisId) => db.devis.find(x => x.id === devisId)
  || db.devis.filter(x => normName(x.clientName) === normName(name)).sort((a, b) => b.date.localeCompare(a.date))[0];
const prestaDesc = d => (isMb(d) ? `${d.mm.nature} – ${cityOf(d.mm.adresse)}` : isMm(d)
  ? `LOCATION DE MONTE-MEUBLE – ${d.mm.nature} – ${cityOf(d.mm.adresse)}`
  : `DÉMÉNAGEMENT ${cityOf(d.from.adresse)} → ${cityOf(d.to.adresse)}`).toUpperCase();
// Reste à facturer (HT) = prix HT du devis - HT déjà facturé (le HT d'une facture sans TVA = le montant net)
const resteHT = (d, prev) => r2(Number(d.prixHT) - prev.reduce((t, f) => t + factTotals(f).ht, 0));
// Ligne de prestation selon le type de facture (complète, acompte, solde)
function kindLine(kind, d, prev) {
  const base = prestaDesc(d);
  if (kind === 'acompte') {
    const ac = docTotals(d).ac;   // pourcentage ou montant fixe (TTC) -> converti en HT pour la ligne de facture
    return { desc: `${acFixed(d) != null ? 'ACOMPTE' : 'ACOMPTE ' + frNum(acPct(d)) + ' %'} – ${base}`, pu: r2(ac / (1 + rateOf(d) / 100)) };
  }
  if (kind === 'solde') {
    const refs = prev.map(f => f.number).join(', ');
    return { desc: `SOLDE – ${base}${refs ? ` (déjà facturé : n° ${refs})` : ''}`, pu: Math.max(0, resteHT(d, prev)) };
  }
  return { desc: base, pu: d.prixHT };
}

function newFact(p = {}) {
  return { id: uid(), isNew: true, kind: 'complete', number: factNumber(), date: iso(new Date()), statut: 'À payer', payeLe: '', payeMode: '', type: 'particulier', sansTva: false, clientName: '', clientAddress: '', clientSiret: '', clientTel: '', modele: 'detail', devisRef: '', livraison: '', bonCommande: '', bonCommandeDate: '', codeEngagement: '', conditions: '',
    lines: [{ ref: '', title: '', desc: '', qty: 1, unit: 'UNITE', pu: '', remise: '' }], ...p };
}

// Petite fenêtre : « une facture existe déjà, faire une facture de solde ? » -> 'esp' | 'tva' | 'other' | 'cancel'
function askSolde({ name, prev, reste, hasDevis, fromDevis }) {
  return new Promise(resolve => {
    const el = document.createElement('div'); el.className = 'dlg';
    const lst = prev.map(f => `<li><b>${esc(f.number)}</b> · ${esc(kindLabel(f))} · ${money(factTotals(f).ttc)}${f.sansTva ? ' (sans TVA)' : ' TTC'} · ${esc(f.statut)}</li>`).join('');
    const full = hasDevis && reste <= 0;
    el.innerHTML = `<div class="dlg-box"><h3>Facture déjà faite pour ${esc(name)}</h3><ul>${lst}</ul>`
      + (full ? '<p>Ce devis est <b>déjà entièrement facturé</b>.</p>'
        : hasDevis ? `<p>Reste à facturer : <b>${money(reste)}</b> HT.</p><p>Faire une facture de solde ?</p>`
        : '<p>Faire une facture de solde ? (le montant sera à saisir)</p>')
      + `<div class="dlg-btns">${full ? '' : '<button class="btn primary" data-c="esp">Solde en espèces (sans TVA)</button><button class="btn primary" data-c="tva">Solde par virement (avec TVA)</button>'}`
      + `<button class="btn" data-c="other">${fromDevis ? 'Ouvrir la dernière facture' : 'Non, continuer cette facture'}</button></div></div>`;
    el.onclick = e => { const c = e.target.dataset.c || (e.target === el ? 'cancel' : null); if (!c) return; el.remove(); resolve(c); };
    document.body.appendChild(el);
  });
}
// Ouvre une facture de solde préremplie (cash = espèces = sans TVA ; sinon virement avec TVA)
function openSolde(d, name, prev, cash) {
  const last = prev[prev.length - 1] || {}, rel = d ? prev.filter(f => !f.devisId || f.devisId === d.id) : prev;
  const l = d ? kindLine('solde', d, rel) : { desc: 'SOLDE', pu: '' };
  openFact(null, {
    kind: 'solde', devisId: d?.id, devisRef: d?.number ?? last.devisRef ?? '', clientTel: d?.clientTel ?? last.clientTel ?? '', livraison: d ? doneDate(d) : '', sansTva: !!cash, clientName: d?.clientName || name,
    clientAddress: d?.clientAddress ?? last.clientAddress ?? '', clientSiret: d?.clientSiret ?? last.clientSiret ?? '',
    type: last.type || (d && d.civ === 'Société' ? 'entreprise' : 'particulier'),
    lines: [{ ref: '', title: l.desc, desc: '', qty: 1, unit: 'UNITE', pu: l.pu, remise: '' }]
  });
}
async function factureFromDevis(d) {
  const prev = factsFor(d.clientName, d.id);
  if (prev.length) {
    const c = await askSolde({ name: d.clientName, prev, reste: resteHT(d, prev.filter(f => !f.devisId || f.devisId === d.id)), hasDevis: true, fromDevis: true });
    if (c === 'esp' || c === 'tva') openSolde(d, d.clientName, prev, c === 'esp');
    else if (c === 'other') openFact(prev[prev.length - 1].id);
    return;
  }
  openFact(null, { clientName: d.clientName, clientAddress: d.clientAddress, clientSiret: d.clientSiret || '', clientTel: d.clientTel || '', type: d.civ === 'Société' ? 'entreprise' : 'particulier',
    devisId: d.id, devisRef: d.number, livraison: doneDate(d), sansTva: !!d.sansTva,
    lines: [{ ref: '', title: prestaDesc(d), desc: '', qty: 1, unit: 'UNITE', pu: d.prixHT, remise: '' }] });
}
function lineHTML(l) {
  return `<div class="line">
    <label>Réf.<input data-k="ref" value="${esc(l.ref)}"></label>
    <label>Prestation<input data-k="title" value="${esc(l.title)}"></label>
    <label>Description<input data-k="desc" value="${esc(l.desc)}"></label>
    <label>Qté<input data-k="qty" type="number" step="any" value="${esc(l.qty)}"></label>
    <label>Unité<input data-k="unit" value="${esc(l.unit ?? 'UNITE')}"></label>
    <label>Prix unitaire HT<input data-k="pu" type="number" step="0.01" value="${esc(l.pu)}"></label>
    <label>Remise %<input data-k="remise" type="number" step="any" value="${esc(l.remise)}"></label>
    <button type="button" class="btn small danger" data-del title="Supprimer la ligne">✕</button></div>`;
}
function readLines() {
  return $$('#lines .line').map(r => { const o = {}; ['ref', 'title', 'desc', 'qty', 'unit', 'pu', 'remise'].forEach(k => { o[k] = $('[data-k=' + k + ']', r).value; }); return o; });
}
function bindLines() {
  $$('#lines [data-del]').forEach(b => b.onclick = () => { b.closest('.line').remove(); updateFactTotals(); });
}
const lineNet = l => r2((Number(l.qty) || 0) * (Number(l.pu) || 0) * (1 - (Number(l.remise) || 0) / 100));
const factTotals = f => {
  const gross = f.lines.reduce((t, l) => t + (Number(l.qty) || 0) * (Number(l.pu) || 0), 0);
  const t = calcTotals(f.lines.reduce((x, l) => x + lineNet(l), 0), rateOf(f), 0);
  t.remise = r2(gross - t.ht); t.acompte = 0; t.reste = t.ttc; return t;   // une facture n'affiche que son total (pas de « reste à payer »)
};
function updateFactTotals() {
  const F = $('#factForm').elements, sans = F.sansTva.checked;
  const t = factTotals({ lines: readLines(), sansTva: sans });
  $('#fTotals').innerHTML = (sans
    ? `<div class="big"><span>Total net à payer (sans TVA)</span><span>${money(t.ttc)}</span></div>`
    : `<div><span>Total HT</span><span>${money(t.ht)}</span></div><div><span>TVA ${db.settings.tvaRate} %</span><span>${money(t.tva)}</span></div><div class="big"><span>Total TTC</span><span>${money(t.ttc)}</span></div>`);
}
let askedKey = '';
function openFact(id, prefill) {
  curFact = id ? structuredClone(db.factures.find(x => x.id === id)) : newFact(prefill);
  curFact.kind ||= 'complete'; askedKey = normName(curFact.clientName);
  fillForm($('#factForm'), curFact);
  $('#lines').innerHTML = curFact.lines.map(lineHTML).join(''); bindLines();
  $('#factTitle').textContent = id ? `Facture ${curFact.number}` : 'Nouvelle facture';
  toggleSiret(); refreshClientList(); updateFactTotals(); updateFactInfo(); show('facturesEdit');
}
function toggleSiret() { $('#siretWrap').classList.toggle('hidden', $('#factForm').elements.type.value !== 'entreprise'); }
$('#factForm').elements.type.onchange = toggleSiret;
$('#addLine').onclick = () => { $('#lines').insertAdjacentHTML('beforeend', lineHTML({ ref: '', title: '', desc: '', qty: 1, unit: 'UNITE', pu: '', remise: '' })); bindLines(); };
$('#factForm').addEventListener('input', updateFactTotals);
autoFillClient($('#factForm'), { name: 'clientName', address: 'clientAddress', siret: 'clientSiret', type: 'type', tel: 'clientTel' });
$('#factForm').addEventListener('autofilled', toggleSiret);
$('#factForm').elements.clientName.addEventListener('change', toggleSiret);

// Bandeau « déjà facturé pour ce client » + question « facture de solde ? » quand on choisit un client qui a déjà une facture
function updateFactInfo() {
  const el = $('#factInfo'), name = $('#factForm').elements.clientName.value;
  const prev = curFact ? factsFor(name, curFact.devisId, curFact.id) : [];
  if (!prev.length) { el.classList.add('hidden'); el.innerHTML = ''; return; }
  const d = devisFor(name, curFact.devisId), rel = d ? prev.filter(f => !f.devisId || f.devisId === d.id) : prev;
  el.innerHTML = '<b>Déjà facturé pour ce client :</b> ' + prev.map(f => `${esc(f.number)} (${esc(kindLabel(f))}, ${money(factTotals(f).ttc)}${f.sansTva ? ' sans TVA' : ' TTC'}, ${esc(f.statut)})`).join(' · ')
    + (d && rel.length ? ` — reste à facturer : <b>${money(resteHT(d, rel))}</b> HT` : '');
  el.classList.remove('hidden');
}
async function checkClient() {
  updateFactInfo();
  const name = $('#factForm').elements.clientName.value.trim(), key = normName(name);
  if (!curFact?.isNew || !key || key === askedKey) return;
  askedKey = key;
  const prev = factsFor(name, curFact.devisId, curFact.id);
  if (!prev.length) return;
  const d = devisFor(name, curFact.devisId), rel = d ? prev.filter(f => !f.devisId || f.devisId === d.id) : prev;
  const c = await askSolde({ name, prev, reste: d ? resteHT(d, rel) : 0, hasDevis: !!d });
  if (c === 'esp' || c === 'tva') openSolde(d, name, prev, c === 'esp');
}
$('#factForm').elements.clientName.addEventListener('change', checkClient);
$('#factForm').addEventListener('autofilled', checkClient);
// Changer le « Type de facture » remplit la 1re ligne (acompte = % du devis, solde = reste à facturer)
$('#factForm').elements.kind.onchange = () => {
  const F = $('#factForm').elements, d = devisFor(F.clientName.value, curFact.devisId), row = $$('#lines .line')[0];
  if (!d) { toast('Aucun devis trouvé pour ce client : saisis le montant à la main'); return; }
  if (!row) return;
  const prev = factsFor(F.clientName.value, d.id, curFact.id).filter(f => !f.devisId || f.devisId === d.id);
  const l = kindLine(F.kind.value, d, prev);
  $('[data-k=title]', row).value = l.desc; $('[data-k=desc]', row).value = ''; $('[data-k=pu]', row).value = l.pu;
  curFact.devisId ||= d.id; updateFactTotals(); updateFactInfo();
};

function collectFact() { const f = { ...curFact, ...readForm($('#factForm')) }; f.lines = readLines(); return f; }
function saveFact(silent) {
  const f = collectFact();
  if (!f.clientName.trim()) { toast('Indique le client à facturer'); return null; }
  const wasNew = f.isNew; delete f.isNew;
  // Sécurité : jamais deux factures avec le même numéro
  if (db.factures.some(x => x.id !== f.id && x.number === f.number)) {
    if (!wasNew) { toast(`Le numéro ${f.number} existe déjà : change-le`); return null; }
    f.number = factNumber(); $('#factForm').elements.number.value = f.number;
    toast(`Numéro déjà pris : cette facture devient la n° ${f.number}`);
  }
  if (wasNew) db.factures.push(f);
  else db.factures[db.factures.findIndex(x => x.id === f.id)] = f;
  upsertClient({ name: f.clientName, address: f.clientAddress, siret: f.clientSiret, type: f.type, tel: f.clientTel });
  saveDB(); curFact = f; $('#factTitle').textContent = `Facture ${f.number}`; updateFactInfo();
  if (!silent) toast('Facture enregistrée');
  return f;
}
$('#fSave').onclick = () => saveFact();
$('#newFact').onclick = () => openFact();

function renderFactures() {
  const q = $('#qFact').value.trim().toLowerCase();
  const flt = $('#fFilter').value;
  const all = db.factures, yr = String(new Date().getFullYear());
  const due = all.filter(f => f.statut !== 'Payée'), cashed = all.filter(f => f.statut === 'Payée' && (f.payeLe || f.date).startsWith(yr));
  $('#factSum').innerHTML = `À encaisser : <b>${money(due.reduce((s, f) => s + factTotals(f).ttc, 0))}</b> (${due.length} facture${due.length > 1 ? 's' : ''}) · Encaissé en ${yr} : <b>${money(cashed.reduce((s, f) => s + factTotals(f).ttc, 0))}</b> (${cashed.length})`;
  const rows = db.factures.filter(f => (!flt || f.statut === flt) && (f.clientName + f.number).toLowerCase().includes(q)).sort((a, b) => {
    // numéro de type "81-2026" : on compare l'année puis le numéro, en nombres (pas en texte, sinon 100 passe avant 99)
    const [na, ya] = String(a.number).split('-').map(Number), [nb, yb] = String(b.number).split('-').map(Number);
    return (ya || 0) - (yb || 0) || (na || 0) - (nb || 0);
  });
  $('#factTable').innerHTML = rows.length ? `
    <tr><th>N°</th><th>Date</th><th>Client</th><th class="r">TTC</th><th>Statut</th><th>Règlement</th><th></th></tr>
    ${rows.map(f => `<tr><td>${esc(f.number)}</td><td>${frDate(f.date)}</td><td>${esc(f.clientName)}${f.kind && f.kind !== 'complete' ? ` <span class="hint">(${esc(kindLabel(f))})</span>` : ''}</td>
      <td class="r">${money(factTotals(f).ttc)}</td>
      <td><select data-st="${f.id}">${['À payer', 'Payée'].map(s => `<option ${s === f.statut ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td>${payCell(f)}</td>
      <td class="r"><button class="btn small" data-o="${f.id}">Ouvrir</button><button class="btn small" data-fm="${f.id}">Email</button><button class="btn small" data-p="${f.id}">PDF</button><button class="btn small danger" data-x="${f.id}">Suppr.</button></td></tr>`).join('')}`
    : `<tr><td class="empty">Aucune facture. Clique sur « Nouvelle facture », ou sur « Facturer » depuis un devis.</td></tr>`;
  const T = $('#factTable');
  $$('[data-o]', T).forEach(b => b.onclick = () => openFact(b.dataset.o));
  $$('[data-p]', T).forEach(b => b.onclick = () => pdf('facture', db.factures.find(x => x.id === b.dataset.p)));
  $$('[data-x]', T).forEach(b => b.onclick = () => { if (confirm('Supprimer cette facture ?')) { db.factures = db.factures.filter(x => x.id !== b.dataset.x); saveDB(); renderFactures(); } });
  $$('[data-fm]', T).forEach(b => b.onclick = () => showFactMail(db.factures.find(x => x.id === b.dataset.fm)));
  $$('[data-st]', T).forEach(s => s.onchange = () => {
    const f = db.factures.find(x => x.id === s.dataset.st); f.statut = s.value;
    if (f.statut === 'Payée') f.payeLe ||= iso(new Date()); else { f.payeLe = ''; f.payeMode = ''; }
    saveDB(); renderFactures();
  });
}
// Colonne « Règlement » : date et mode si payée, sinon depuis combien de jours elle attend
function payCell(f) {
  if (f.statut === 'Payée') return `<span class="ok">payée${f.payeLe ? ' le ' + frDate(f.payeLe) : ''}</span>${f.payeMode ? `<br><span class="hint">${esc(f.payeMode)}</span>` : ''}`;
  const n = Math.floor((Date.now() - new Date(f.date + 'T12:00:00').getTime()) / 86400000);
  return n >= 30 ? `<span class="warn">en attente depuis ${n} j</span>` : `<span class="hint">en attente (${Math.max(n, 0)} j)</span>`;
}
$('#qFact').oninput = renderFactures; $('#fFilter').onchange = renderFactures;
// Dans le formulaire : choisir « Payée » remplit la date du jour ; repasser à « À payer » l'efface
$('#factForm').addEventListener('change', e => {
  if (e.target.name !== 'statut') return;
  const F = $('#factForm').elements;
  if (e.target.value === 'Payée') { if (!F.payeLe.value) F.payeLe.value = iso(new Date()); } else { F.payeLe.value = ''; F.payeMode.value = ''; }
});
$('#fMail').onclick = () => { const f = collectFact(); if (!f.clientName.trim()) { toast('Indique le client à facturer'); return; } showFactMail(f); };

/* =====================================================
   LETTRES DE VOITURE
   ===================================================== */
let curLettre = null;
const lettreNumber = () => `${db.settings.nextLettre}-${year()}`;
const emptyPoint = () => ({ periode: '', adresse: '', etage: '', lat: '', lon: '' });
function newLettre(p = {}) {
  return {
    id: uid(), isNew: true, number: lettreNumber(), date: iso(new Date()),
    civ: 'M.', clientName: '', clientTel: '', clientAddress: '', clientSiret: '',
    categorie: 'ÉCONOMIQUE', volume: '', voyage: 'NATIONAL', mode: 'ROUTE', distance: '',
    from: emptyPoint(), to: emptyPoint(), prixHT: '', paiement: 'acompte', reglement: 'facture', sansTva: false, acompteVerse: '', garantie: true,
    vehicules: '', obsChef: '', remarques: '', ...p
  };
}
// Depuis un devis : tout est repris (client, adresses, dates, prix). Si la lettre existe déjà, on l'ouvre.
function lettreFromDevis(d) {
  const ex = db.lettres.find(l => l.devisId === d.id);
  if (ex) { openLettre(ex.id); toast('Une lettre de voiture existe déjà pour ce devis'); return; }
  const pt = a => ({ periode: a.periode || '', adresse: a.adresse || '', etage: a.etage || '', lat: a.lat || '', lon: a.lon || '' });
  openLettre(null, {
    devisId: d.id, civ: d.civ, clientName: d.clientName, clientTel: d.clientTel, clientAddress: d.clientAddress, clientSiret: d.clientSiret || '',
    categorie: d.categorie, volume: d.volume, voyage: d.voyage, distance: d.distance,
    from: pt(d.from), to: pt(d.to), prixHT: d.prixHT, paiement: d.paiement || 'acompte', sansTva: !!d.sansTva, garantie: d.garantie,
    acMode: d.acMode || 'pct', acVal: d.acVal ?? '', acompteVerse: acRecu(d) || ''
  });
}
// Acompte : calculé d'après le prix, sauf si on saisit un montant à la main.
// Paiement en espèces (pas de facture) : aucun acompte automatique, seulement celui qu'on saisit.
function lettreTotals(l) {
  const cash = l.reglement === 'especes';
  const unique = payMode(l) === 'unique';
  const noTva = cash || !!l.sansTva;   // espèces = TVA non applicable : on reste sur le HT
  const t = calcTotals(l.prixHT, noTva ? 0 : db.settings.tvaRate, (unique || cash) ? 0 : acPct(l), (unique || cash) ? null : acFixed(l));
  const over = String(l.acompteVerse ?? '').trim();
  t.custom = false;
  if (over !== '' && !isNaN(Number(over))) { t.ac = r2(over); t.solde = r2(t.ttc - t.ac); t.custom = true; }
  t.unique = unique; t.cash = cash; t.sansTva = noTva; return t;
}
function openLettre(id, prefill) {
  curLettre = id ? structuredClone(db.lettres.find(x => x.id === id)) : newLettre(prefill);
  curLettre.paiement ||= 'acompte'; curLettre.reglement ||= 'facture';
  fillForm($('#lettreForm'), curLettre); toggleLettreCiv(false);
  $('#lettreTitle').textContent = id ? `Lettre de voiture ${curLettre.number}` : 'Nouvelle lettre de voiture';
  refreshClientList(); updateLettreTotals(); show('lettresEdit');
}
function toggleLettreCiv(changed) {
  const f = $('#lettreForm'), soc = f.elements.civ.value === 'Société';
  $('#lSiretWrap').classList.toggle('hidden', !soc); $('#lPayWrap').classList.toggle('hidden', !soc);
  if (changed) f.elements.paiement.value = soc && db.settings.acompteEntreprise === false ? 'unique' : 'acompte';
  updateLettreTotals();
}
function collectLettre() {
  const l = { ...curLettre, ...readForm($('#lettreForm')) };
  l.from = { ...emptyPoint(), ...l.from }; l.to = { ...emptyPoint(), ...l.to };
  return l;
}
function updateLettreTotals() {
  if (!curLettre) return;
  const t = lettreTotals(collectLettre());
  $('#lTotals').innerHTML = (t.sansTva
    ? `<div><span>Prix HT</span><span>${money(t.ht)}</span></div>
    <div><span>TVA non applicable${t.cash ? ' (espèces)' : ''}</span><span>${money(0)}</span></div>
    <div class="big"><span>Total à payer</span><span>${money(t.ttc)}</span></div>`
    : `<div><span>Prix HT</span><span>${money(t.ht)}</span></div>
    <div><span>TVA ${db.settings.tvaRate} %</span><span>${money(t.tva)}</span></div>
    <div class="big"><span>Prix TTC</span><span>${money(t.ttc)}</span></div>`) + `
    <div><span>${t.cash ? (t.ac > 0 ? 'Acompte versé en espèces' : 'Aucun acompte') : t.unique ? 'Acompte (aucun : règlement en une fois)' : 'Acompte versé'}</span><span>${money(t.ac)}</span></div>
    <div><span>Solde restant dû</span><span>${money(t.solde)}</span></div>`;
}
$('#lettreForm').elements.civ.onchange = () => toggleLettreCiv(true);
$('#lettreForm').addEventListener('autofilled', () => toggleLettreCiv(true));
['input', 'change'].forEach(ev => $('#lettreForm').addEventListener(ev, updateLettreTotals));
autoFillClient($('#lettreForm'), { name: 'clientName', civ: 'civ', tel: 'clientTel', address: 'clientAddress', siret: 'clientSiret' });
$('#btnKmL').onclick = () => calcDistance($('#lettreForm'), false);

function saveLettre(silent) {
  const l = collectLettre();
  if (!l.clientName.trim()) { toast('Indique le nom du client'); return null; }
  const wasNew = l.isNew; delete l.isNew;
  if (wasNew) { db.lettres.push(l); db.settings.nextLettre++; }
  else db.lettres[db.lettres.findIndex(x => x.id === l.id)] = l;
  upsertClient({ name: l.clientName, civ: l.civ, tel: l.clientTel, address: l.clientAddress, siret: l.clientSiret, type: l.civ === 'Société' ? 'entreprise' : '' });
  saveDB(); curLettre = l; $('#lettreTitle').textContent = `Lettre de voiture ${l.number}`;
  if (!silent) toast('Lettre de voiture enregistrée');
  return l;
}
$('#lSave').onclick = () => saveLettre();
$('#newLettre').onclick = () => openLettre();

function renderLettres() {
  const q = $('#qLettre').value.trim().toLowerCase();
  const rows = db.lettres.filter(l => (l.clientName + l.number).toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date) || b.number.localeCompare(a.number));
  $('#lettreTable').innerHTML = rows.length ? `
    <tr><th>N°</th><th>Date</th><th>Client</th><th>Trajet</th><th class="r">Solde dû</th><th></th></tr>
    ${rows.map(l => `<tr><td>${esc(l.number)}</td><td>${frDate(l.date)}</td><td>${esc(l.clientName)}</td>
      <td>${esc(cityOf(l.from.adresse))} → ${esc(cityOf(l.to.adresse))}</td><td class="r">${money(lettreTotals(l).solde)}</td>
      <td class="r"><button class="btn small" data-o="${l.id}">Ouvrir</button><button class="btn small" data-p="${l.id}">PDF</button><button class="btn small danger" data-x="${l.id}">Suppr.</button></td></tr>`).join('')}`
    : `<tr><td class="empty">Aucune lettre de voiture. Clique sur « Lettre de voiture » depuis un devis, ou sur « Nouvelle lettre de voiture ».</td></tr>`;
  const T = $('#lettreTable');
  $$('[data-o]', T).forEach(b => b.onclick = () => openLettre(b.dataset.o));
  $$('[data-p]', T).forEach(b => b.onclick = () => pdf('lettre', db.lettres.find(x => x.id === b.dataset.p)));
  $$('[data-x]', T).forEach(b => b.onclick = () => { if (confirm('Supprimer cette lettre de voiture ?')) { db.lettres = db.lettres.filter(x => x.id !== b.dataset.x); saveDB(); renderLettres(); } });
}
$('#qLettre').oninput = renderLettres;

/* =====================================================
   CLIENTS
   ===================================================== */
function renderClients() {
  const q = $('#qCli').value.trim().toLowerCase();
  const rows = db.clients.filter(c => c.name.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
  $('#cliTable').innerHTML = rows.length ? `
    <tr><th>Client</th><th>Téléphone</th><th>Email</th><th>Adresse</th><th>Devis</th><th>Factures</th><th></th></tr>
    ${rows.map(c => {
    const nd = db.devis.filter(d => d.clientName.toLowerCase() === c.name.toLowerCase()).length;
    const nf = db.factures.filter(d => d.clientName.toLowerCase() === c.name.toLowerCase()).length;
    return `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.tel)}</td><td>${esc(c.email)}</td><td>${esc(c.address)}</td><td>${nd}</td><td>${nf}</td>
      <td class="r"><button class="btn small" data-d="${c.id}">Nouveau devis</button><button class="btn small" data-e="${c.id}">Modifier</button><button class="btn small danger" data-x="${c.id}">Suppr.</button></td></tr>`;
  }).join('')}` : `<tr><td class="empty">Les clients s'ajoutent tout seuls quand tu enregistres un devis ou une facture.</td></tr>`;
  const T = $('#cliTable');
  $$('[data-d]', T).forEach(b => b.onclick = () => { const c = db.clients.find(x => x.id === b.dataset.d); openDevis(null, { clientName: c.name, civ: c.civ || 'M.', clientTel: c.tel || '', clientEmail: c.email || '', clientAddress: c.address || '' }); });
  $$('[data-e]', T).forEach(b => b.onclick = () => editClient(db.clients.find(x => x.id === b.dataset.e)));
  $$('[data-x]', T).forEach(b => b.onclick = () => { if (confirm('Supprimer ce client ? (ses devis et factures sont conservés)')) { db.clients = db.clients.filter(x => x.id !== b.dataset.x); saveDB(); renderClients(); } });
}
function editClient(c) {
  const n = prompt('Nom', c.name); if (n === null) return;
  c.name = n.trim() || c.name;
  const t = prompt('Téléphone', c.tel || ''); if (t !== null) c.tel = t;
  const m = prompt('Email', c.email || ''); if (m !== null) c.email = m;
  const a = prompt('Adresse', c.address || ''); if (a !== null) c.address = a;
  saveDB(); renderClients();
}
$('#newClient').onclick = () => { const n = prompt('Nom du client'); if (!n) return; upsertClient({ name: n }); saveDB(); renderClients(); };
$('#qCli').oninput = renderClients;

/* =====================================================
   AGENDA
   ===================================================== */
let cal = new Date(); cal.setDate(1);
function renderAgenda() {
  refreshClientList();
  const y = cal.getFullYear(), m = cal.getMonth();
  $('#mLabel').textContent = cal.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  const offset = (new Date(y, m, 1).getDay() + 6) % 7, n = new Date(y, m + 1, 0).getDate(), today = iso(new Date());
  let h = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => `<div class="dow">${d}</div>`).join('');
  for (let i = 0; i < offset; i++) h += '<div class="day off"></div>';
  for (let d = 1; d <= n; d++) {
    const ds = iso(new Date(y, m, d));
    const ev = db.events.filter(e => e.date === ds).map(e => `<div class="chip"><span data-ev="${e.id}" title="${esc(e.title)}">${esc(e.title)}</span><button data-del="${e.id}" title="Retirer">✕</button></div>`).join('');
    h += `<div class="day ${ds === today ? 'today' : ''}"><b>${d}</b>${ev}</div>`;
  }
  $('#cal').innerHTML = h;
  $$('#cal [data-del]').forEach(b => b.onclick = () => { db.events = db.events.filter(e => e.id !== b.dataset.del); saveDB(); renderAgenda(); });
  $$('#cal [data-ev]').forEach(s => s.onclick = () => { const e = db.events.find(x => x.id === s.dataset.ev); if (e.devisId && db.devis.some(d => d.id === e.devisId)) openDevis(e.devisId); });
}
$('#mPrev').onclick = () => { cal.setMonth(cal.getMonth() - 1); renderAgenda(); };
$('#mNext').onclick = () => { cal.setMonth(cal.getMonth() + 1); renderAgenda(); };
$('#mToday').onclick = () => { cal = new Date(); cal.setDate(1); renderAgenda(); };
$('#evAdd').onclick = () => {
  const f = $('#evForm'), name = f.elements.client.value.trim(), date = f.elements.date.value;
  if (!name || !date) { toast('Indique le client et la date'); return; }
  const dv = db.devis.filter(d => d.clientName.toLowerCase() === name.toLowerCase()).sort((a, b) => b.date.localeCompare(a.date))[0];
  const note = f.elements.note.value.trim();
  const title = dv && isMm(dv) ? `${dv.clientName} – ${isMb(dv) ? 'démontage / remontage' : 'monte-meuble'} – ${cityOf(dv.mm.adresse)}${dv.clientTel ? ' – ' + dv.clientTel : ''}` : dv ? `${dv.clientName}${dv.volume ? ' – ' + dv.volume + ' m³' : ''} – ${cityOf(dv.from.adresse)} → ${cityOf(dv.to.adresse)}${dv.clientTel ? ' – ' + dv.clientTel : ''}` : name;
  db.events.push({ id: uid(), date, title: title + (note ? ' – ' + note : ''), devisId: dv?.id });
  saveDB(); cal = new Date(date + 'T12:00'); cal.setDate(1); f.reset(); renderAgenda(); toast('Ajouté à l\'agenda');
};

/* =====================================================
   RÉGLAGES
   ===================================================== */
function renderSettings() {
  fillForm($('#setForm'), db.settings);
  const sp = $('#signPrev'); sp.src = db.settings.signature || ''; sp.classList.toggle('hidden', !db.settings.signature);
  updateBackupUI();
}
$('#sSave').onclick = () => {
  const v = readForm($('#setForm'));
  ['nextDevis', 'nextFacture', 'nextLettre', 'tvaRate', 'acompte'].forEach(k => v[k] = Number(v[k]) || DEFAULTS.settings[k]);
  db.settings = { ...db.settings, ...v }; saveDB(); applyBrand(); toast('Réglages enregistrés');
};
function readImage(file, key) {
  if (!file) return; const r = new FileReader();
  r.onload = () => { db.settings[key] = r.result; saveDB(); renderSettings(); applyBrand(); toast('Image enregistrée'); };
  r.readAsDataURL(file);
}
$('#upLogo').onchange = e => readImage(e.target.files[0], 'logo');
$('#upSign').onchange = e => readImage(e.target.files[0], 'signature');
$('#exp').onclick = () => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(db)], { type: 'application/json' }));
  a.download = `sauvegarde-djk-${iso(new Date())}.json`; a.click();
  try { localStorage.setItem('djk_last_export', String(Date.now())); } catch (x) { /* facultatif */ } updateBackupUI();
};
$('#imp').onchange = e => {
  const file = e.target.files[0]; if (!file) return;
  file.text().then(t => { try { db = { ...structuredClone(DEFAULTS), ...JSON.parse(t) }; db.settings = { ...DEFAULTS.settings, ...db.settings }; migrate(db); saveDB(); toast('Sauvegarde restaurée'); renderSettings(); applyBrand(); } catch (x) { toast('Fichier invalide'); } });
};
function applyBrand() { $('#brandLogo').src = logoSrc(); }

/* =====================================================
   MODÈLES PDF
   ===================================================== */
const footer = s => `<div class="foot"><b>${esc(s.tagline)}</b>${esc(s.company)}<br>${esc(s.address1)} - ${esc(s.address2)} - tél : ${esc(s.tel)}<br>${esc(s.legal)}</div>`;
const tri = (v, note) => esc(v || 'N/C') + (note ? ` (${esc(note)})` : '');
function accLines(a) {
  return [`Type de logement : ${esc(a.type)}`,
  `Étage : ${esc(a.etage || 'N/C')} – Portage : ${esc(a.portage || 'N/C')} m`,
  `Ascenseur : ${tri(a.ascenseur, a.ascenseurNote)}`, `Monte-meubles : ${tri(a.monte)}`, `Passage fenêtre : ${tri(a.fenetre)}`,
  `Transbordement : ${tri(a.transbordement)}`, `Autorisation de stationnement : ${tri(a.stationnement, a.stationnementNote)}`].join('<br>');
}
function devisHTML(d) {
  const s = db.settings, t = docTotals(d);
  const sal = d.civ === 'Mme' ? 'Madame' : d.civ === 'Société' ? 'Madame, Monsieur' : 'Monsieur';
  const civTxt = d.civ === 'Société' ? '' : d.civ + ' ';
  const head = `<div class="head"><img class="logo" src="${logoSrc()}" alt=""><div class="ref">
      <div class="big"><b>${esc(s.city)} LE : ${frDate(d.date)}</b></div>
      <div><b>Devis n° ${esc(d.number)}</b></div>
      <div><b>Nom du client :</b> ${civTxt}${esc(d.clientName)}</div>
      <div style="max-width:470px;margin-left:auto"><b>Adresse :</b> ${esc([d.clientAddress, d.clientTel && 'Tél : ' + d.clientTel, d.clientEmail && 'Email : ' + d.clientEmail].filter(Boolean).join(' — '))}</div></div></div>`;
  if (isMm(d)) return mmDevisHTML(d, head, s, t, sal);
  const mob = (d.mobilier || '').split('\n').map(x => x.trim()).filter(Boolean);
  const garantie = d.garantie ? `<tr><td colspan="2"><b>${esc(s.garantieText.split('\n')[0])}</b><br>${esc(s.garantieText.split('\n').slice(1).join(' '))} (taux d'assurance : ${esc(s.taux)} %)</td><td class="n">Incluse</td></tr>` : '';
  return `
  <div class="page devis">${head}<hr>
    <p class="mail">${esc(s.email)}</p>
    <h3 style="font-size:15px">${sal},</h3>
    <p>Nous vous remercions pour l'accueil que vous avez bien voulu nous réserver lors de nos échanges.</p>
    <p>Conformément à votre demande, nous avons le plaisir de vous adresser notre devis personnalisé pour votre projet de déménagement.</p>
    <p>Nous espérons que notre proposition retiendra favorablement votre attention et restons à votre entière disposition pour toute information complémentaire.</p>
    <p>Si notre offre correspond à vos attentes, nous vous invitons à nous retourner le devis daté et signé afin de confirmer votre déménagement.</p>
    <p>Nous vous remercions de votre confiance et serons ravis de vous accompagner dans la réalisation de votre projet.</p>
    <div class="sign-dir">La direction,</div>
    ${footer(s)}</div>

  <div class="page devis brk">${head}<hr>
    <p class="mail" style="margin-bottom:6px">${esc(s.email)}</p>
    <div class="visit">${d.visited ? `<b>Visité par :</b> ${esc(d.visitedBy)} <b>le :</b> ${frDate(d.visitedDate)}` : `<b>Visite :</b> non effectuée`}</div>
    <table><tr><td class="k">Catégorie</td><td>${esc(d.categorie)}</td><td class="k">Volume</td><td>${esc(d.volume)} m³</td></tr>
    <tr><td class="k">Voyage</td><td>${esc(d.voyage)}</td><td class="k">Distance</td><td>${esc(frNum(d.distance))} km</td></tr></table>
    <table><tr><th style="width:12%"></th><th>CHARGEMENT</th><th>LIVRAISON</th></tr>
      <tr><td class="k">Date</td><td>${frDay(d.from.periode)}</td><td>${frDay(d.to.periode)}</td></tr>
      <tr><td class="k">Adresse</td><td>${esc(d.from.adresse)}</td><td>${esc(d.to.adresse)}</td></tr>
      <tr><td class="k">Accès</td><td class="acc">${accLines(d.from)}</td><td class="acc">${accLines(d.to)}</td></tr></table>
    ${mob.length ? `<h3>MOBILIER ET ÉLÉMENTS À TRANSPORTER</h3><ul>${mob.map(m => `<li>${esc(m)}</li>`).join('')}</ul>` : ''}
    ${d.particularite ? `<p><b>Particularité :</b> ${nl(d.particularite)}</p>` : ''}
    <h3>DÉTAIL DU PRIX</h3>
    ${priceTable(d, s, t, garantie)}
    ${payRow(d, t, 'à la livraison')}
    <div class="sigs">
      <div><b>Pour ${esc(s.company)}</b><br>Date : ${frDate(d.date)}${sealHTML()}</div>
      <div><b>Le client</b><br>Date : ____/____/________<br>Mention manuscrite « Bon pour accord » :<br>Signature</div></div>
    <p style="text-align:center;margin:0 0 8px">Merci de votre confiance — DJK Déménagement</p>
    ${footer(s)}</div>`;
}
// Tableau « détail du prix » : avec TVA, ou sans TVA (prix net)
function priceTable(d, s, t, garantie) {
  if (d.sansTva) return `<table class="price">${garantie}
      <tr class="ttc"><td colspan="2">PRIX NET À PAYER – TVA non applicable (Valable jusqu'au ${frDate(d.valid)})</td><td class="n">${money(t.ttc)}</td></tr></table>`;
  return `<table class="price"><tr><td colspan="2"><b>PRIX H.T.</b></td><td class="n">${money(t.ht)}</td></tr>
      ${garantie}
      <tr><td colspan="2">TVA ${s.tvaRate} % SUR (${money(t.ht)} en H.T.)</td><td class="n">${money(t.tva)}</td></tr>
      <tr class="ttc"><td colspan="2">PRIX T.T.C (Valable jusqu'au ${frDate(d.valid)})</td><td class="n">${money(t.ttc)}</td></tr></table>`;
}
function mmDevisHTML(d, head, s, t, sal) {
  const m = d.mm, mb = isMb(d);
  return `<div class="page devis">${head}<hr>
    <p class="mail">${esc(s.email)}</p>
    <h3 style="font-size:15px">${sal},</h3>
    <p>Conformément à votre demande, nous avons le plaisir de vous adresser notre devis pour votre intervention ${mb ? 'de ' + esc(m.nature.toLowerCase()) : 'avec monte-meuble'}. Si notre offre vous convient, merci de nous le retourner daté et signé.</p>
    <h3>${mb ? 'DEVIS DÉMONTAGE / REMONTAGE DE MEUBLES' : 'DEVIS MONTE-MEUBLE'}</h3>
    <table>
      <tr><td class="k">Nature</td><td>${esc(m.nature)}</td><td class="k">Date</td><td>${frDay(m.date)}${m.dateFin && m.dateFin !== m.date ? '<br>au ' + frDay(m.dateFin) : ''}${m.heure ? ' à ' + esc(m.heure) : ''}</td></tr>
      <tr><td class="k">Adresse</td><td colspan="3">${esc(m.adresse)}</td></tr>
      <tr><td class="k">Durée prévue</td><td>${esc(m.duree || 'N/C')}</td><td class="k">Logement</td><td>${esc(m.type)} – étage ${esc(m.etage || 'N/C')}</td></tr>
      <tr><td class="k">Accès</td><td colspan="3" class="acc">${mb ? '' : `Passage fenêtre / balcon : ${tri(m.fenetre)}<br>`}Autorisation de stationnement : ${tri(m.stationnement, m.stationnementNote)}</td></tr>
      <tr><td class="k">${mb ? 'Meubles' : 'Objet'}</td><td colspan="3">${nl(m.objet)}</td></tr>
      ${m.remarque ? `<tr><td class="k">Remarques</td><td colspan="3">${esc(m.remarque)}</td></tr>` : ''}
    </table>
    <h3>DÉTAIL DU PRIX</h3>
    ${priceTable(d, s, t, '')}
    ${payRow(d, t, 'le jour de la prestation')}
    <div class="sigs">
      <div><b>Pour ${esc(s.company)}</b><br>Date : ${frDate(d.date)}${sealHTML()}</div>
      <div><b>Le client</b><br>Date : ____/____/________<br>Mention manuscrite « Bon pour accord » :<br>Signature</div></div>
    <p style="text-align:center;margin:0 0 8px">Merci de votre confiance — DJK Déménagement</p>
    ${footer(s)}</div>`;
}
/* ---------- « Bon pour accord » + signature au stylo (devis uniquement, pas de tampon) ---------- */
// Si une image de signature est enregistrée dans les Réglages, on l'utilise ; sinon une signature manuscrite « DJK » est dessinée.
const penSign = () => {
  const first = esc(String(db.settings.company || 'DJK').split(' ')[0]);
  return db.settings.signature
    ? `<img class="sig" src="${db.settings.signature}" alt="">`
    : `<span class="pen">${first}</span><svg class="penline" viewBox="0 0 130 22" width="130" height="22"><path d="M3 15 C 22 1, 42 21, 66 9 S 108 5, 126 13" fill="none" stroke="#1b2f86" stroke-width="2.3" stroke-linecap="round"/></svg>`;
};
const sealHTML = () => `<div class="seal"><span class="bpa">Bon pour accord</span>${penSign()}</div>`;

// Ligne « paiement » du devis : avec acompte, ou règlement en une fois (entreprises)
const payRow = (d, t, when) => payMode(d) === 'unique'
  ? `<table class="pay"><tr><td>Aucun acompte : règlement en une seule fois le jour de la prestation</td>
      <td style="width:18%"><b>${money(0)}</b></td><td style="width:18%"><b>${money(t.ttc)}</b></td></tr></table>`
  : `<table class="pay"><tr><td>${acLabel(d)}, le solde ${when}<br><small>(Pour les entreprises : bon de commande, règlement à réception de facture)</small></td>
      <td style="width:18%"><b>${money(t.ac)}</b></td><td style="width:18%"><b>${money(t.solde)}</b></td></tr></table>`;

// Ligne de prix de la lettre : toujours HT et TTC. Sans TVA (ou espèces) : TVA non applicable, on reste sur le HT.
function lettrePrice(t) {
  return t.sansTva
    ? `<p><b>Prix HT :</b> ${money(t.ht)} &emsp; <b>TVA :</b> non applicable &emsp; <b>Prix à payer :</b> ${money(t.ttc)}</p>`
    : `<p><b>Prix HT :</b> ${money(t.ht)} &emsp; <b>TVA ${db.settings.tvaRate} % :</b> ${money(t.tva)} &emsp; <b>Prix TTC :</b> ${money(t.ttc)}</p>`;
}
// Paiement en espèces (pas de facture) : règlement, acompte s'il y en a un, solde
function lettrePayCash(t) {
  const ligne1 = `<p><b>Règlement :</b> en espèces (sans facture)</p>`;
  const ligne2 = t.ac > 0
    ? `<p><b>Acompte versé :</b> ${money(t.ac)} &emsp; <b>Solde restant dû :</b> <span class="red">${money(t.solde)}</span></p>`
    : `<p><b>Acompte versé :</b> aucun &emsp; <b>Solde restant dû :</b> <span class="red">${money(t.solde)}</span> (règlement en une fois)</p>`;
  return ligne1 + ligne2;
}
// Trajet hors Île-de-France ? Détecté d'après le code postal des adresses (départements 75, 77, 78, 91, 92, 93, 94, 95).
// Le champ « horsIdf » du formulaire permet de forcer : '' = automatique, 'oui', 'non'.
const IDF_DEPTS = ['75', '77', '78', '91', '92', '93', '94', '95'];
const deptOf = a => { const m = String(a || '').match(/\b(\d{5})\b/); return m ? m[1].slice(0, 2) : null; };
function lettreHorsIdf(l) {
  if (l.horsIdf === 'oui') return true;
  if (l.horsIdf === 'non') return false;
  return [l.from?.adresse, l.to?.adresse].some(a => { const d = deptOf(a); return d && !IDF_DEPTS.includes(d); });
}
// Hors IDF : 2 exemplaires (client + entreprise), 3 cases de signature. Sinon : 1 exemplaire, 2 cases.
function lettreHTML(l) {
  if (!lettreHorsIdf(l)) return lettrePage(l, 'CHARGEMENT ET LIVRAISON', false);
  return lettrePage(l, 'CLIENT', true) + lettrePage(l, 'ENTREPRISE', true);
}
function lettrePage(l, exemplaire, horsIdf) {
  const s = db.settings, t = lettreTotals(l);
  const civTxt = l.civ === 'Société' ? '' : (l.civ || '') + ' ';
  const g = (s.garantieText || '').split('\n').map(x => x.trim()).filter(Boolean);
  const gTitle = g[0] ? g[0].charAt(0).toUpperCase() + g[0].slice(1).toLowerCase() : '';
  const garantie = l.garantie && g.length ? `<p><b>Garantie :</b> ${esc(gTitle)}${g.length > 1 ? ' — ' + esc(g.slice(1).join(' ')) : ''} (taux d'assurance : ${esc(s.taux)} %)</p>` : '';
  const pay = t.cash ? lettrePayCash(t) : t.unique
    ? `<p><b>Acompte versé :</b> ${money(0)} (aucun acompte demandé) &emsp; <b>Solde restant dû :</b> <span class="red">${money(t.solde)}</span> (règlement en une fois le jour de la prestation)</p>`
    : `<p><b>Acompte versé :</b> ${money(t.ac)}${(t.custom || acFixed(l) != null) ? '' : ` (${frNum(acPct(l))} % de ${money(t.ttc)} TTC)`} &emsp; <b>Solde restant dû :</b> <span class="red">${money(t.solde)}</span></p>`;
  return `<div class="page lv">
    <div class="head">
      <div><img class="logo" src="${logoSrc()}" alt=""><div class="me">${esc(s.address1)} - ${esc(s.address2)}<br>Siret : ${esc(fmtSiret(s.siret))}<br>Tél : ${esc(s.tel)}<br><i>${esc(s.email)}</i></div></div>
      <div class="rt"><span class="t">LETTRE DE VOITURE N° ${esc(l.number)}</span>
        <div class="small">Document obligatoire par arrêté du 09/11/1999</div>
        <div class="b">Exemplaire ${exemplaire}${horsIdf ? ` (${exemplaire === 'CLIENT' ? 1 : 2}/2)` : ''}</div>
        <div class="b">Client : ${civTxt}${esc(l.clientName)}</div>
        ${l.clientSiret ? `<div class="b">Siret client : ${esc(fmtSiret(l.clientSiret))}</div>` : ''}
        <div class="b">Dossier n° : ${esc(l.number)}</div></div>
    </div>
    <hr>
    <div class="info">
      <div>Catégorie : ${esc(l.categorie)}</div><div>Volume (m3) : ${l.volume ? esc(frNum(l.volume)) : '___'}</div><div>Voyage : ${esc(l.voyage)}</div>
      <div>Mode d'exécution : ${esc(l.mode)}</div><div>Distance (km) : ${l.distance !== '' && l.distance != null ? esc(frNum(l.distance)) : '___'}</div><div></div>
    </div>
    <div class="exe"><b>Entreprise exécutante : ${esc(s.company)}</b> &nbsp; Siret : ${esc(fmtSiret(s.siret))}</div>
    <table><tr><th>CHARGEMENT</th><th>LIVRAISON</th></tr>
      <tr><td>Date :<br>${esc(frLong(l.from.periode))}</td><td>Date :<br>${esc(frLong(l.to.periode))}</td></tr>
      <tr><td>Adresse :<br>${esc(l.from.adresse)}</td><td>Adresse :<br>${esc(l.to.adresse)}</td></tr>
      <tr><td>Étage :  ${esc(l.from.etage || 'N/C')}</td><td>Étage :  ${esc(l.to.etage || 'N/C')}</td></tr></table>
    ${garantie}${lettrePrice(t)}${pay}
    <p><b>Véhicule(s) :</b> ${esc(l.vehicules)}</p>
    <p class="lbl">Observations du chef d'équipe au chargement :</p><div class="box">${esc(l.obsChef)}</div>
    <p class="lbl">Remarques du client (réserves, dommages constatés...) :</p><div class="box">${esc(l.remarques)}</div>
    ${horsIdf ? `<div class="sigs3">
      <div><b>SIGNATURE CHARGEMENT</b><br><small><i>Client, à l'enlèvement</i></small></div>
      <div><b>SIGNATURE DÉCHARGEMENT</b><br><small><i>Client, à la livraison</i></small></div>
      <div><b>SIGNATURE DU CHEF D'ÉQUIPE</b><br>${esc(s.company)}<br><small><i>À la fin des travaux</i></small></div>
    </div>` : `<div class="sigs2">
      <div><b>SIGNATURE DU CLIENT</b><br><small><i>Mention manuscrite « bon pour accord »</i></small></div>
      <div><b>SIGNATURE DE L'ENTREPRISE</b><br>${esc(s.company)}<br><small><i>Signature du chef de chantier, à la fin des travaux</i></small></div>
    </div>`}
    ${footer(s)}</div>`;
}

const ribOf = iban => { const c = String(iban || '').replace(/\s/g, ''); return c.length === 27 ? { banque: c.slice(4, 9), guichet: c.slice(9, 14), compte: c.slice(14, 25), cle: c.slice(25, 27) } : null; };
const num2 = n => (Number(n) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const factureHTML = f => (f.modele || 'simple') === 'detail' ? factureDetailHTML(f) : factureSimpleHTML(f);
// Modèle détaillé (comme la facture au GRETA) : références, colonnes, RIB, conditions de paiement
function factureDetailHTML(f) {
  const s = db.settings, t = factTotals(f), rate = f.sansTva ? 0 : Number(s.tvaRate) || 0, rib = ribOf(s.iban);
  const lines = f.lines.filter(l => l.title || l.desc || l.pu || l.ref);
  const rows = lines.map(l => {
    const rem = Number(l.remise) || 0, old = l.title === 'LISTE DES PRESTATIONS' && l.desc;
    return `<tr class="row"><td class="ref">${esc(l.ref)}</td><td><b>${esc(old ? l.desc : l.title)}</b>${!old && l.desc ? `<br><span class="sub">${nl(l.desc)}</span>` : ''}</td>
      <td class="c">${num2(l.qty)}</td><td class="c">${esc(l.unit || '')}</td><td class="r">${num2(l.pu)}</td><td class="r">${rem ? frNum(rem) + ' %' : ''}</td><td class="r">${num2(lineNet(l))}</td><td class="c">${num2(rate)} %</td></tr>`;
  }).join('');
  const fill = `<tr><td style="height:${Math.max(40, 560 - lines.length * 46)}px"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`;
  const suivi = f.bonCommande ? `Suivi du BON DE COMMANDE n° ${esc(f.bonCommande)}${f.bonCommandeDate ? '<br>du ' + frDate(f.bonCommandeDate) : ''}` : f.devisRef ? `Suivi du devis n° ${esc(f.devisRef)}` : '';
  const pairs = [['Date de facture', frDate(f.date)], f.livraison && ['Livraison le', frDate(f.livraison)], f.devisRef && ['Référence du devis', esc(f.devisRef)], f.codeEngagement && ['Code engagement', esc(f.codeEngagement)]].filter(Boolean);
  let info = '';
  for (let i = 0; i < pairs.length; i += 2) {
    const a = pairs[i], b = pairs[i + 1];
    info += `<tr><td class="l">${a[0]}</td><td class="v">${a[1]}</td>${b ? `<td class="l">${b[0]}</td><td class="v">${b[1]}</td>` : '<td></td><td></td>'}</tr>`;
  }
  return `<div class="page fact2">
    <div class="f2-top"><img class="logo" src="${logoSrc()}" alt=""><div class="f2-title"><div class="t">Facture N°${esc(f.number)}</div><div class="s">${suivi}</div></div></div>
    <div class="f2-parties">
      <div class="me"><b>${esc(s.company)}</b><br>${esc(s.address1)}<br>${esc(s.address2)}<br><b>Siret</b> : ${esc(s.siret)}<br><b>N° TVA</b> : ${esc(s.tva)}<br><b>Tél</b> : ${esc(s.tel.replace(/\s/g, ''))}</div>
      <div class="cli"><b>${esc(f.clientName)}</b><br>${nl(f.clientAddress)}${f.type === 'entreprise' && f.clientSiret ? `<br><b>Siret</b> : ${esc(f.clientSiret)}` : ''}${f.clientTel ? `<br><b>Tél</b> : ${esc(f.clientTel)}` : ''}</div></div>
    <table class="f2-info">${info}</table>
    <table class="f2-lines"><tr><th style="width:11%">Votre référence</th><th>Désignation</th><th style="width:6%">Qté</th><th style="width:8%">Unité</th><th style="width:10%">PU HT</th><th style="width:8%">Remise</th><th style="width:12%">Montant HT</th><th style="width:9%">TVA</th></tr>${rows}${fill}</table>
    <div class="f2-bottom">
      <div class="f2-bank"><b>Titulaire du compte</b> : ${esc(s.company)}<br><b>IBAN</b> : ${esc(s.iban)}<br><b>BIC</b> : ${esc(s.bic || '')}
        ${rib ? `<br><br><b>RIB</b><br>Banque ${rib.banque} &nbsp;Indicatif ${rib.guichet} &nbsp;N° Compte ${rib.compte} &nbsp;Clé RIB ${rib.cle}` : ''}${s.signature ? `<img src="${s.signature}" alt="">` : ''}</div>
      <table class="f2-tot"><tr><td>Conditions de facturation</td><td class="r">Total en EUR</td></tr>
        <tr><td>Montant HT</td><td class="r">${num2(t.ht + t.remise)}</td></tr><tr><td>Montant remises</td><td class="r">${num2(t.remise)}</td></tr>
        <tr><td>TVA (${num2(rate)} %)</td><td class="r">${num2(t.tva)}</td></tr><tr class="b"><td>Total TTC</td><td class="r">${num2(t.ttc)}</td></tr></table></div>
    <div class="f2-pay"><span class="h">Modalités de règlement</span><span class="tt">TOTAL TTC</span></div>
    <div class="f2-pay2"><div>Conditions de paiement : ${esc(f.conditions || 'VIREMENT SEPA')}</div><div class="amt">${num2(t.ttc)} EUR</div></div>
    <div class="foot">Merci de votre confiance — DJK Déménagement<br>${esc(s.tagline)}<br>${esc(s.company)}<br>${esc(s.address1)} - ${esc(s.address2)} - tél : ${esc(s.tel)}<br>${esc(s.legal)}</div>
  </div>`;
}
function factureSimpleHTML(f) {
  const s = db.settings, t = factTotals(f), sans = !!f.sansTva;
  const rows = f.lines.filter(l => l.title || l.desc || l.pu).map(l => {
    const tot = lineNet(l);
    return `<tr><td><b>${esc(l.title)}</b><br><span class="sub">${esc(l.desc)}</span></td><td class="c">${esc(l.qty)}</td><td class="c">${money(l.pu)}</td><td class="c">${money(tot)}</td></tr>`;
  }).join('');
  return `<div class="page fact">
    <div class="top2"><img class="logo" src="${logoSrc()}" alt=""><div class="title">Facture N°${esc(f.number)}</div></div>
    <div class="me"><b>${esc(s.company)}</b><br>${esc(s.address1)}<br>${esc(s.address2)}<br><b>Siret</b> : ${esc(s.siret)}<br><b>N° TVA</b> : ${esc(s.tva)}<br><b>Tél</b> : ${esc(s.tel.replace(/\s/g, ''))}</div>
    <div class="cli"><b>${esc(f.clientName)}</b><br>${esc(f.clientAddress)}${f.type === 'entreprise' && f.clientSiret ? `<br><b>Siret</b> : ${esc(f.clientSiret)}` : ''}</div>
    <div class="box date"><div class="row"><div class="gray">Date de facture</div><div>${frDate(f.date)}</div></div></div>
    <table><tr><th>Description</th><th style="width:15%">Quantité</th><th style="width:22%">Prix unitaire${sans ? '' : ' HT'}</th><th style="width:22%">Prix total${sans ? '' : ' HT'}</th></tr>${rows}</table>
    <div class="bottom">
      <div class="iban">${esc(s.iban)}${s.signature ? `<img src="${s.signature}" alt="">` : ''}</div>
      <div class="box tot">
        ${sans
          ? `<div class="row"><div>TVA</div><div>non applicable</div></div><div class="row b"><div>Total net à payer</div><div>${money(t.ttc)}</div></div>`
          : `<div class="row"><div>Total HT</div><div>${money(t.ht)}</div></div>
        <div class="row"><div>TVA (${Number(s.tvaRate).toFixed(2).replace('.', ',')} %)</div><div>${money(t.tva)}</div></div>
        <div class="row b"><div>Total TTC</div><div>${money(t.ttc)}</div></div>`}</div></div>
    <div class="foot">Merci de votre confiance — DJK Déménagement<br>${esc(s.tagline)}<br>${esc(s.company)}<br>${esc(s.address1)} - ${esc(s.address2)} - tél : ${esc(s.tel)}<br>${esc(s.legal)}</div>
  </div>`;
}

/* =====================================================
   APERÇU ET TÉLÉCHARGEMENT PDF
   ===================================================== */
const fileName = (kind, doc) => {
  const who = (doc.clientName || 'client').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '_');
  return `${{ devis: 'Devis', facture: 'Facture', lettre: 'Lettre_de_voiture' }[kind]}_${doc.number.replace(/[^\w-]+/g, '_')}_${who}.pdf`;
};
// Filigrane : le logo est converti en noir, très clair (calculé dans le navigateur à partir du logo des Réglages)
let wmUrl = '', wmCache = { src: '', url: '' };
async function setWatermark() {
  wmUrl = '';
  if (db.settings.watermark === false) return;
  try {
    const src = logoSrc();
    if (wmCache.src !== src) {
      const img = new Image(); img.src = src; await new Promise(r => { img.onload = img.onerror = r; });
      if (!img.naturalWidth) return;
      const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight;
      const x = c.getContext('2d'); x.drawImage(img, 0, 0);
      const im = x.getImageData(0, 0, c.width, c.height), q = im.data;
      for (let i = 0; i < q.length; i += 4) {
        const lum = .299 * q[i] + .587 * q[i + 1] + .114 * q[i + 2];
        const a = Math.max(0, Math.min(1, (250 - lum) / 200)) * (q[i + 3] / 255);
        q[i] = q[i + 1] = q[i + 2] = 0; q[i + 3] = Math.round(a * 255 * 0.09);   // noir, 9 % d'opacité
      }
      x.putImageData(im, 0, 0); wmCache = { src, url: c.toDataURL('image/png') };
    }
    wmUrl = wmCache.url;
  } catch (e) { console.warn('Filigrane indisponible', e); }
}
const withWm = html => wmUrl ? html.replace(/<div class="page([^"]*)">/g, (m, c) => `<div class="page${c}"><img class="wm" src="${wmUrl}" alt="">`) : html;
const buildHTML = (kind, doc) => withWm(({ devis: devisHTML, facture: factureHTML, lettre: lettreHTML }[kind])(doc));
// Documents facultatifs à joindre à la suite du devis (fichiers du dossier assets/docs)
const PRESTA_FILES = { 'ÉCONOMIQUE': 'presta-economique', 'ÉCONOMIQUE PLUS': 'presta-economique-plus', 'STANDARD': 'presta-standard', 'GRAND CONFORT': 'presta-grand-confort', 'LUXE': 'presta-prestige', 'TRANSPORT DU MOBILIER': 'presta-transport-mobilier' };
const ANNEX_FILES = { assurance: ["Attestation d'assurance 2026", 'attestation-assurance-2026'], valeur: ['Déclaration de valeur', 'declaration-de-valeur'], cgv: ['Conditions générales de vente', 'conditions-generales-de-vente'], rib: ['RIB', 'rib-djk'] };
function annexList(d) {
  const a = d.annexes || {}, L = [];
  if (a.presta && !isMm(d) && PRESTA_FILES[d.categorie]) L.push([`Détail de la prestation ${d.categorie.toLowerCase()}`, `assets/docs/${PRESTA_FILES[d.categorie]}.pdf`]);
  ['assurance', 'valeur', 'cgv', 'rib'].forEach(k => { if (a[k]) L.push([ANNEX_FILES[k][0], `assets/docs/${ANNEX_FILES[k][1]}.pdf`]); });
  return L;
}
async function saveWithAnnexes(out, extra, name) {
  try {
    if (!window.PDFLib) throw new Error('pdf-lib absent');
    const merged = await PDFLib.PDFDocument.load(out.output('arraybuffer'));
    for (const [label, url] of extra) {
      const r = await fetch(url); if (!r.ok) throw new Error(label);
      const src = await PDFLib.PDFDocument.load(await r.arrayBuffer(), { ignoreEncryption: true });
      (await merged.copyPages(src, src.getPageIndices())).forEach(pg => merged.addPage(pg));
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([await merged.save()], { type: 'application/pdf' })); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast(`PDF téléchargé avec ${extra.length} document${extra.length > 1 ? 's' : ''} joint${extra.length > 1 ? 's' : ''}`);
  } catch (e) { console.error(e); out.save(name); toast('Devis téléchargé SANS les documents joints : ouvre l’appli avec http://localhost:5500 et vérifie ta connexion'); }
}
async function pdf(kind, doc) {
  const root = $('#pdfRoot'); await setWatermark(); root.innerHTML = buildHTML(kind, doc);
  try {
    if (!window.html2canvas || !window.jspdf) throw new Error('libs');
    await Promise.all($$('img', root).map(i => i.complete ? 1 : new Promise(r => { i.onload = i.onerror = r; })));
    try { await document.fonts.load('600 24px Caveat'); await document.fonts.ready; } catch (e) { /* police manuscrite : on continue sans */ }
    const { jsPDF } = window.jspdf;
    const out = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
    const pages = $$('.page', root);
    for (let i = 0; i < pages.length; i++) {
      const canvas = await html2canvas(pages[i], {
        scale: 2, useCORS: true, backgroundColor: '#ffffff', scrollX: 0, scrollY: 0, windowWidth: 794,
        onclone: d => { const h = d.getElementById('pdfHide'); if (h) { h.style.left = '0'; h.style.position = 'absolute'; } }
      });
      let w = 210, h = canvas.height / canvas.width * 210;
      if (h > 297) { const f = 297 / h; w *= f; h = 297; }
      if (i > 0) out.addPage();
      out.addImage(canvas.toDataURL('image/jpeg', 0.98), 'JPEG', (210 - w) / 2, 0, w, h);
    }
    const extra = kind === 'devis' ? annexList(doc) : [];
    if (extra.length) await saveWithAnnexes(out, extra, fileName(kind, doc)); else { out.save(fileName(kind, doc)); toast('PDF téléchargé'); }
  } catch (e) { console.error(e); toast('Erreur PDF : vérifie ta connexion internet puis recharge la page'); }
  root.innerHTML = '';
}
let modalCtx = null;
async function preview(kind, doc) {
  modalCtx = [kind, doc]; await setWatermark();
  const m = $('#modalDoc'); m.innerHTML = buildHTML(kind, doc);
  m.style.zoom = Math.min(1, (innerWidth - 40) / 794);
  $('#modal').classList.remove('hidden');
}
$('#mClose').onclick = () => $('#modal').classList.add('hidden');
$('#mPdf').onclick = () => pdf(...modalCtx);
$('#dPreview').onclick = () => preview('devis', collectDevis());
$('#fPreview').onclick = () => preview('facture', collectFact());
$('#lPreview').onclick = () => preview('lettre', collectLettre());
$('#lPdf').onclick = () => { const l = saveLettre(true); if (l) pdf('lettre', l); };
$('#dPdf').onclick = () => { const d = saveDevis(true); if (d) pdf('devis', d); };
$('#fPdf').onclick = () => { const f = saveFact(true); if (f) pdf('facture', f); };

/* =====================================================
   SAUVEGARDES : dossier automatique + copies internes + export Excel
   ===================================================== */
// Petite base IndexedDB (clé -> valeur) : le navigateur y garde les copies et le « dossier choisi »
const idb = (() => {
  let p;
  const open = () => p ||= new Promise((res, rej) => {
    const r = indexedDB.open('djk_backup', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const tx = async (mode, fn) => {
    const d = await open();
    return new Promise((res, rej) => { const t = d.transaction('kv', mode), out = fn(t.objectStore('kv')); t.oncomplete = () => res(out.result); t.onerror = () => rej(t.error); });
  };
  return { get: k => tx('readonly', s => s.get(k)), set: (k, v) => tx('readwrite', s => s.put(v, k)), del: k => tx('readwrite', s => s.delete(k)), keys: () => tx('readonly', s => s.getAllKeys()) };
})();
const bk = { handle: null, perm: 'none', timer: null, last: '', lastWrite: '', err: '' };
const canPick = 'showDirectoryPicker' in window;
const hasData = () => !!(db.devis.length || db.factures.length || db.lettres.length || db.clients.length);
const counts = j => { try { const d = JSON.parse(j); return `${d.devis?.length || 0} devis, ${d.factures?.length || 0} factures, ${d.lettres?.length || 0} lettres`; } catch (e) { return ''; } };

function scheduleBackup() { clearTimeout(bk.timer); bk.timer = setTimeout(() => runBackup(false), 1500); }
async function runBackup(force) {
  if (!hasData()) return;   // jamais de sauvegarde d'une base vide : elle écraserait une bonne copie
  const json = JSON.stringify(db);
  try { await snapshot(json, force); } catch (e) { console.warn('copie interne impossible', e); }
  await writeFolder(json);
  updateBackupUI();
}
// Copie interne : une nouvelle copie à chaque modification (si le contenu a changé)
async function snapshot(json, force) {
  if (json === bk.last && !force) return;
  bk.last = json;
  const ts = String(Date.now()).padStart(15, '0');
  await idb.set('snap:' + ts, json);
  await idb.set('meta:' + ts, { at: Date.now(), label: counts(json) });
  await pruneSnaps();
}
// On garde les 30 plus récentes, puis la dernière de chaque jour pendant 60 jours
async function pruneSnaps() {
  const keys = (await idb.keys()).map(String).filter(k => k.startsWith('snap:')).sort().reverse();
  const days = new Set(), limit = Date.now() - 60 * 86400000;
  for (const [i, k] of keys.entries()) {
    const ms = Number(k.slice(5)), day = iso(new Date(ms));
    const keep = i < 30 || (!days.has(day) && ms > limit);
    days.add(day);
    if (!keep) { await idb.del(k); await idb.del('meta:' + k.slice(5)); }
  }
}
async function writeFolder(json) {
  if (!bk.handle) return;
  try {
    bk.perm = await bk.handle.queryPermission({ mode: 'readwrite' });
    if (bk.perm !== 'granted') return;
    const put = async name => { const fh = await bk.handle.getFileHandle(name, { create: true }); const w = await fh.createWritable(); await w.write(json); await w.close(); };
    await put('djk-sauvegarde-derniere.json');
    await put(`djk-sauvegarde-${iso(new Date())}.json`);   // un fichier par jour : l'historique se construit tout seul
    bk.lastWrite = new Date().toLocaleString('fr-FR'); bk.err = '';
  } catch (e) { bk.err = e.message || String(e); }
}
async function restoreSnap(ts) {
  const json = await idb.get('snap:' + ts); if (!json) return;
  if (!confirm('Remplacer les données actuelles par cette copie ? (une copie de l\'état actuel est gardée avant)')) return;
  await snapshot(JSON.stringify(db), true);
  db = { ...structuredClone(DEFAULTS), ...JSON.parse(json) }; db.settings = { ...DEFAULTS.settings, ...db.settings }; migrate(db);
  saveDB(); renderSettings(); applyBrand(); toast('Copie restaurée');
}
async function renderSnaps() {
  const T = $('#snapTable'); let keys = [];
  try { keys = (await idb.keys()).map(String).filter(k => k.startsWith('meta:')).sort().reverse().slice(0, 40); } catch (e) { /* IndexedDB indisponible */ }
  const metas = await Promise.all(keys.map(k => idb.get(k)));
  T.innerHTML = keys.length ? `<tr><th>Date et heure</th><th>Contenu</th><th></th></tr>` + keys.map((k, i) =>
    `<tr><td>${new Date(metas[i].at).toLocaleString('fr-FR')}</td><td>${esc(metas[i].label)}</td><td class="r"><button type="button" class="btn small" data-rs="${k.slice(5)}">Restaurer</button></td></tr>`).join('')
    : `<tr><td class="empty">Aucune copie pour l'instant : elles apparaissent dès que tu enregistres un devis.</td></tr>`;
  $$('[data-rs]', T).forEach(b => b.onclick = () => restoreSnap(b.dataset.rs));
}
function updateBackupUI() {
  const st = $('#bkStatus'); if (!st) return;
  const paused = bk.handle && bk.perm !== 'granted';
  let msg, cls = 'notice';
  if (!canPick) msg = 'Ce navigateur ne sait pas écrire dans un dossier : ouvre l\'appli avec Chrome ou Edge. En attendant, télécharge une sauvegarde régulièrement.';
  else if (!bk.handle) msg = 'Aucun dossier choisi : pour l\'instant tes données sont gardées uniquement dans ce navigateur.';
  else if (paused) msg = `En pause : le navigateur demande de confirmer l'accès au dossier « ${bk.handle.name} » à chaque ouverture. Clique sur « Réactiver ».`;
  else msg = `Actif : dossier « ${bk.handle.name} ». ${bk.lastWrite ? 'Dernière écriture : ' + bk.lastWrite + '.' : 'Écriture au prochain enregistrement.'}${bk.err ? ' Erreur : ' + bk.err : ''}`;
  st.textContent = msg;
  $('#bkPick').classList.toggle('hidden', !canPick); $('#bkPick').textContent = bk.handle ? 'Changer de dossier' : 'Choisir le dossier de sauvegarde';
  $('#bkAllow').classList.toggle('hidden', !paused);
  // Bandeau en haut de toutes les pages
  const bar = $('#bkBar'), last = Number(localStorage.getItem('djk_last_export') || 0), days = Math.floor((Date.now() - last) / 86400000);
  let bm = '', bt = '';
  if (hasData() && paused) { bm = 'La sauvegarde automatique est en pause.'; bt = 'Réactiver'; }
  else if (hasData() && !bk.handle && (!last || days >= 7)) { bm = last ? `Aucune sauvegarde sur ton PC depuis ${days} jours.` : 'Tes données ne sont sauvegardées nulle part sur ton PC.'; bt = 'Sauvegarder'; }
  bar.classList.toggle('hidden', !bm); $('#bkMsg').textContent = bm; $('#bkBarBtn').textContent = bt;
  if (!$('#view-settings').classList.contains('hidden')) renderSnaps();
}
$('#bkPick').onclick = async () => {
  try {
    const h = await window.showDirectoryPicker({ id: 'djk-backup', mode: 'readwrite' });
    bk.handle = h; bk.perm = 'granted';
    try { await idb.set('dir', h); } catch (x) { console.warn('dossier non mémorisé', x); }   // mémorisé pour les prochaines ouvertures
    await runBackup(true); toast('Sauvegarde automatique activée');
  } catch (e) { if (e.name !== 'AbortError') toast('Dossier impossible : ' + (e.message || e)); }
  updateBackupUI();
};
$('#bkAllow').onclick = async () => { try { bk.perm = await bk.handle.requestPermission({ mode: 'readwrite' }); } catch (e) { /* refusé */ } await runBackup(true); };
$('#bkNow').onclick = async () => {
  if (!hasData()) { toast('Rien à sauvegarder pour l\'instant'); return; }
  await runBackup(true);
  toast(bk.handle && bk.perm === 'granted' ? 'Sauvegarde écrite dans le dossier' : 'Copie interne faite (choisis un dossier pour écrire aussi sur ton PC)');
};
$('#bkBarBtn').onclick = async () => {
  if (bk.handle && bk.perm !== 'granted') { try { bk.perm = await bk.handle.requestPermission({ mode: 'readwrite' }); } catch (e) { /* refusé */ } await runBackup(true); }
  else show('settings');
};
async function initBackup() {
  try { navigator.storage?.persist?.(); } catch (e) { /* facultatif */ }   // demande au navigateur de ne pas effacer les données tout seul
  try { bk.handle = (await idb.get('dir')) || null; if (bk.handle) bk.perm = await bk.handle.queryPermission({ mode: 'readwrite' }); } catch (e) { bk.perm = 'denied'; }
  await runBackup(false); updateBackupUI();
}

/* Export Excel (CSV avec « ; », lisible directement par Excel en français) */
function downloadCSV(name, rows) {
  const body = rows.map(r => r.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + body], { type: 'text/csv;charset=utf-8' })); a.download = name; a.click();
}
const num = n => frNum(r2(n));
const asText = v => v ? `="${String(v).replace(/"/g, '""')}"` : '';   // garde le 0 au début d'un numéro de téléphone dans Excel
function devisRows() {
  const head = ['N° devis', 'Date du devis', 'Statut', 'Client', 'Téléphone', 'Email', 'Type', 'Date chargement', 'Adresse départ', 'Étage départ', 'Date livraison', 'Adresse arrivée', 'Étage arrivée',
    'Volume m³', 'Distance km', 'Prix HT', 'Prix TTC', 'Acompte demandé', 'Acompte reçu', 'Date acompte reçu', 'Mode acompte', 'Reste à encaisser', 'Factures liées'];
  const rows = [...db.devis].sort((a, b) => b.date.localeCompare(a.date)).map(d => {
    const t = docTotals(d), r = acRecu(d), mm = isMm(d);
    return [d.number, frDate(d.date), d.statut, d.clientName, asText(d.clientTel), d.clientEmail, mm ? (isMb(d) ? 'Démontage / remontage' : 'Monte-meuble') : 'Déménagement',
      frDate(mm ? d.mm.date : d.from.periode), mm ? d.mm.adresse : d.from.adresse, mm ? d.mm.etage : d.from.etage,
      mm ? '' : frDate(d.to.periode), mm ? '' : d.to.adresse, mm ? '' : d.to.etage, frNum(d.volume), frNum(d.distance),
      num(t.ht), num(t.ttc), payMode(d) === 'unique' ? '' : num(t.ac), r ? num(r) : '', frDate(d.acRecuDate), d.acRecuMode || '', num(t.ttc - r),
      factsFor(d.clientName, d.id).map(f => f.number).join(' + ')];
  });
  return [head, ...rows];
}
function factRows() {
  const head = ['N° facture', 'Date', 'Client', 'Type', 'Statut', 'Payée le', 'Mode de paiement', 'Total HT', 'TVA', 'Total TTC', 'Sans TVA', 'N° devis lié'];
  const rows = [...db.factures].sort((a, b) => b.date.localeCompare(a.date)).map(f => {
    const t = factTotals(f);
    return [f.number, frDate(f.date), f.clientName, kindLabel(f), f.statut, frDate(f.payeLe), f.payeMode || '', num(t.ht), num(t.tva), num(t.ttc), f.sansTva ? 'oui' : '', db.devis.find(d => d.id === f.devisId)?.number || ''];
  });
  return [head, ...rows];
}
$('#csvDevis').onclick = () => downloadCSV(`djk-historique-devis-${iso(new Date())}.csv`, devisRows());
$('#csvFact').onclick = () => downloadCSV(`djk-historique-factures-${iso(new Date())}.csv`, factRows());

/* =====================================================
   POINTAGE DE L'ÉQUIPE : jours en lignes, personnes en colonnes
   ===================================================== */
let ptMonth = iso(new Date()).slice(0, 7);
const dim = ym => new Date(+ym.slice(0, 4), +ym.slice(5, 7), 0).getDate();
const monthLabel = ym => { const t = new Date(+ym.slice(0, 4), +ym.slice(5, 7) - 1, 1).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }); return t.charAt(0).toUpperCase() + t.slice(1); };
const shiftMonth = (ym, n) => { const d = new Date(+ym.slice(0, 4), +ym.slice(5, 7) - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
const numOf = v => Number(String(v ?? '').replace(',', '.')) || 0;
const emptyCell = () => ({ x: false, amt: '', plate: '', note: '' });
const ptCells = ym => (db.pointage.cells[ym] ||= {});
function openDlg(html, handler) {
  const el = document.createElement('div'); el.className = 'dlg'; el.innerHTML = `<div class="dlg-box">${html}</div>`;
  el.onclick = e => { const c = e.target.dataset.c || (e.target === el ? 'close' : null); if (!c) return; if (handler(c, el) !== false) el.remove(); };
  document.body.appendChild(el); return el;
}
// Paie d'une personne pour un mois : jours cochés x (tarif du jour, ou montant spécial de la case) + ajout - avance
function ptPay(p, ym) {
  const cells = db.pointage.cells[ym]?.[p.id] || {}, adj = db.pointage.adj[ym]?.[p.id] || {};
  let jours = 0, brut = 0;
  Object.values(cells).forEach(c => { if (c.x) { jours++; brut += String(c.amt ?? '').trim() !== '' ? numOf(c.amt) : numOf(p.rate); } });
  const ajout = numOf(adj.ajout), avance = numOf(adj.avance);
  return { jours, brut: r2(brut), ajout, avance, reste: r2(brut + ajout - avance) };
}
function renderPointage() {
  const ym = ptMonth, P = db.pointage.people, n = dim(ym), wd = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
  $('#pLabel').textContent = monthLabel(ym);
  if (!P.length) { $('#pTable').innerHTML = '<div class="empty">Aucune personne pour l’instant. Clique sur « + Ajouter des personnes » (tu peux coller tous les noms d’un coup, un par ligne).</div>'; return; }
  const cells = db.pointage.cells[ym] || {}, adj = db.pointage.adj[ym] || {};
  let h = '<table><thead><tr><th class="day">Jour</th>' + P.map(p => `<th data-edit="${p.id}" title="Modifier / supprimer">${esc(p.name)}</th>`).join('') + '</tr></thead><tbody>';
  for (let d = 1; d <= n; d++) {
    const dt = new Date(+ym.slice(0, 4), +ym.slice(5, 7) - 1, d), we = dt.getDay() === 0 || dt.getDay() === 6;
    h += `<tr class="${we ? 'we' : ''}"><td class="day">${wd[dt.getDay()]} ${d}</td>` + P.map(p => {
      const c = cells[p.id]?.[d], on = !!c?.x, a = String(c?.amt ?? '').trim();
      return `<td><button type="button" class="pt-cell ${on ? 'on' : 'off'}" data-p="${p.id}" data-d="${d}" title="${esc(c?.note || '')}">${on ? 'X' : '0 €'}${on && a !== '' ? `<small>${esc(a)} €</small>` : ''}${c?.plate ? `<small>${esc(c.plate)}</small>` : ''}<span class="ed" data-ed="1">✎</span></button></td>`;
    }).join('') + '</tr>';
  }
  const foot = (label, f) => `<tr><td class="day">${label}</td>${P.map(p => `<td>${f(p)}</td>`).join('')}</tr>`;
  h += '</tbody><tfoot>'
    + foot('Jours', p => `<span data-tot="jours" data-p="${p.id}"></span>`)
    + foot('Total jours', p => `<span data-tot="brut" data-p="${p.id}"></span>`)
    + foot('Ajout €', p => `<input data-adj="ajout" data-p="${p.id}" inputmode="decimal" value="${esc(adj[p.id]?.ajout ?? '')}">`)
    + foot('Avance €', p => `<input data-adj="avance" data-p="${p.id}" inputmode="decimal" value="${esc(adj[p.id]?.avance ?? '')}">`)
    + foot('Reste à payer', p => `<b data-tot="reste" data-p="${p.id}"></b>`)
    + '</tfoot></table><p class="hint" style="padding:12px">Total équipe à payer (après avances) : <b id="pGrand"></b></p>';
  $('#pTable').innerHTML = h; updatePtTotals();
}
function updatePtTotals() {
  let all = 0;
  db.pointage.people.forEach(p => {
    const t = ptPay(p, ptMonth); all += t.reste;
    $$(`[data-tot][data-p="${p.id}"]`, $('#pTable')).forEach(el => { el.textContent = el.dataset.tot === 'jours' ? t.jours : money(el.dataset.tot === 'brut' ? t.brut : t.reste); });
  });
  const g = $('#pGrand'); if (g) g.textContent = money(r2(all));
}
$('#pTable').addEventListener('click', e => {
  const th = e.target.closest('[data-edit]'); if (th) { editPerson(th.dataset.edit); return; }
  const b = e.target.closest('.pt-cell'); if (!b) return;
  const pid = b.dataset.p, d = b.dataset.d;
  if (e.target.dataset.ed) { editCell(pid, d); return; }
  const row = (ptCells(ptMonth)[pid] ||= {}), c = row[d] ||= emptyCell();
  c.x = !c.x; if (!c.x) c.amt = '';
  if (!c.x && !c.plate && !c.note) delete row[d];
  saveDB(); renderPointage();
});
$('#pTable').addEventListener('change', e => {
  const k = e.target.dataset.adj; if (!k) return;
  const m = (db.pointage.adj[ptMonth] ||= {}), a = (m[e.target.dataset.p] ||= {});
  a[k] = e.target.value.trim(); saveDB(); updatePtTotals();
});
function editCell(pid, d) {
  const p = db.pointage.people.find(x => x.id === pid); if (!p) return;
  const c = { ...emptyCell(), ...(db.pointage.cells[ptMonth]?.[pid]?.[d] || {}) };
  openDlg(`<h3>${esc(p.name)} – ${d} ${esc(monthLabel(ptMonth).toLowerCase())}</h3><div class="stack">
    <label class="switch"><input type="checkbox" data-f="x" ${c.x ? 'checked' : ''}><i></i>A travaillé ce jour</label>
    <label>Montant spécial ce jour (€) – vide = tarif habituel<input data-f="amt" inputmode="decimal" value="${esc(c.amt)}" placeholder="ex : 40 pour une demi-journée"></label>
    <label>Immatriculation du véhicule<input data-f="plate" value="${esc(c.plate)}" placeholder="AB-123-CD"></label>
    <label>Note<input data-f="note" value="${esc(c.note)}"></label></div>
    <div class="dlg-btns"><button class="btn primary" data-c="ok">Enregistrer</button><button class="btn" data-c="close">Annuler</button></div>`,
  (cmd, el) => {
    if (cmd !== 'ok') return;
    const g = k => $(`[data-f=${k}]`, el);
    const nw = { x: g('x').checked, amt: g('amt').value.trim(), plate: g('plate').value.trim().toUpperCase(), note: g('note').value.trim() };
    if (nw.amt !== '') nw.x = true;
    const row = (ptCells(ptMonth)[pid] ||= {});
    if (!nw.x && !nw.plate && !nw.note) delete row[d]; else row[d] = nw;
    saveDB(); renderPointage();
  });
}
function editPerson(pid) {
  const p = db.pointage.people.find(x => x.id === pid); if (!p) return;
  openDlg(`<h3>${esc(p.name)}</h3><div class="stack">
    <label>Nom<input data-f="name" value="${esc(p.name)}"></label>
    <label>Tarif par jour (€)<input data-f="rate" inputmode="decimal" value="${esc(p.rate ?? '')}"></label></div>
    <div class="dlg-btns"><button class="btn primary" data-c="ok">Enregistrer</button><button class="btn" data-c="close">Annuler</button><button class="btn danger" data-c="del">Supprimer cette personne</button></div>`,
  (cmd, el) => {
    if (cmd === 'del') { if (!confirm(`Supprimer ${p.name} et tout son pointage ?`)) return false; db.pointage.people = db.pointage.people.filter(x => x.id !== pid); Object.values(db.pointage.cells).forEach(m => delete m[pid]); Object.values(db.pointage.adj).forEach(m => delete m[pid]); }
    else if (cmd === 'ok') { p.name = $('[data-f=name]', el).value.trim() || p.name; p.rate = $('[data-f=rate]', el).value.trim(); }
    else return;
    saveDB(); renderPointage();
  });
}
$('#pAdd').onclick = () => openDlg(`<h3>Ajouter des personnes</h3><div class="stack">
    <label>Un nom par ligne<textarea data-f="names" rows="8"></textarea></label>
    <label>Tarif par jour (€) – facultatif, modifiable ensuite<input data-f="rate" inputmode="decimal"></label></div>
    <div class="dlg-btns"><button class="btn primary" data-c="ok">Ajouter</button><button class="btn" data-c="close">Annuler</button></div>`,
(cmd, el) => {
  if (cmd !== 'ok') return;
  const names = $('[data-f=names]', el).value.split('\n').map(x => x.trim()).filter(Boolean), rate = $('[data-f=rate]', el).value.trim();
  names.forEach(nm => db.pointage.people.push({ id: uid(), name: nm, rate }));
  if (names.length) { saveDB(); renderPointage(); toast(`${names.length} personne${names.length > 1 ? 's' : ''} ajoutée${names.length > 1 ? 's' : ''}`); }
});
$('#pPrev').onclick = () => { ptMonth = shiftMonth(ptMonth, -1); renderPointage(); };
$('#pNext').onclick = () => { ptMonth = shiftMonth(ptMonth, 1); renderPointage(); };
$('#pPrint').onclick = () => window.print();

/* =====================================================
   CAISSE DU MOIS : dépenses, espèces encaissées, prestations avec Robert
   ===================================================== */
let moisYm = iso(new Date()).slice(0, 7);
const MOIS_SECS = [
  { key: 'especes', title: 'Prestations encaissées en espèces', types: ['Déménagement', 'Monte-meuble', 'Démontage / remontage', 'Autre'], label: 'Client / description' },
  { key: 'depenses', title: 'Dépenses du mois', types: null, label: 'Dépense' },
  { key: 'robert', title: 'Prestations faites avec Robert', types: ['Déménagement', 'Monte-meuble', 'Gars en plus', 'Autre'], label: 'Description' }
];
const moisStore = ym => { const m = (db.compta[ym] ||= {}); MOIS_SECS.forEach(sc => { m[sc.key] ||= []; }); return m; };
const rowsOf = (ym, k) => db.compta[ym]?.[k] || [];
const sumRows = rows => r2(rows.reduce((t, r) => t + numOf(r.amount), 0));
function renderMois() {
  const ym = moisYm, M = moisStore(ym);
  $('#mLabel2').textContent = monthLabel(ym);
  const secHTML = sc => `<div class="card"><h2>${sc.title}</h2><div class="tbl-scroll"><table class="mois"><thead><tr><th style="width:140px">Date</th>${sc.types ? '<th style="width:190px">Type</th>' : ''}<th>${sc.label}</th><th style="width:130px">Montant (€)</th><th style="width:44px"></th></tr></thead><tbody>`
    + (M[sc.key].length ? M[sc.key].map(r => `<tr data-k="${sc.key}" data-id="${r.id}"><td><input type="date" data-f="date" value="${esc(r.date)}"></td>${sc.types ? `<td><select data-f="type">${sc.types.map(t => `<option${t === r.type ? ' selected' : ''}>${t}</option>`).join('')}</select></td>` : ''}<td><input data-f="label" value="${esc(r.label)}"></td><td><input data-f="amount" inputmode="decimal" value="${esc(r.amount)}"></td><td><button type="button" class="btn small danger" data-del>✕</button></td></tr>`).join('') : `<tr><td colspan="5" class="empty">Aucune ligne.</td></tr>`)
    + `</tbody></table></div><div class="sec-foot"><button type="button" class="btn small" data-add="${sc.key}">+ Ajouter une ligne</button><span class="hint grow" data-types="${sc.key}"></span><b data-sectot="${sc.key}"></b></div></div>`;
  $('#moisBody').innerHTML = MOIS_SECS.map(secHTML).join('')
    + `<div class="card"><h2>Bilan du mois</h2><div class="bilan" id="moisBilan"></div><div class="sec-foot"><button type="button" class="btn" id="robFact">Créer la facture pour Robert</button></div></div>`;
  updateMoisTotals();
}
function updateMoisTotals() {
  const ym = moisYm, byKey = {};
  MOIS_SECS.forEach(sc => {
    const rows = rowsOf(ym, sc.key); byKey[sc.key] = sumRows(rows);
    $(`[data-sectot="${sc.key}"]`).textContent = 'Total : ' + money(byKey[sc.key]);
    $(`[data-types="${sc.key}"]`).textContent = sc.types ? sc.types.map(t => [t, sumRows(rows.filter(r => r.type === t))]).filter(x => x[1]).map(x => `${x[0]} : ${money(x[1])}`).join(' · ') : '';
  });
  const equipe = r2(db.pointage.people.reduce((t, p) => t + ptPay(p, ym).reste, 0));
  $('#moisBilan').innerHTML = `<div><span>Espèces encaissées</span><span>${money(byKey.especes)}</span></div>
    <div><span>Dépenses</span><span>− ${money(byKey.depenses)}</span></div>
    <div class="big"><span>Espèces moins dépenses</span><span>${money(r2(byKey.especes - byKey.depenses))}</span></div>
    <div><span>Équipe : reste à payer (pointage, après avances)</span><span>${money(equipe)}</span></div>
    <div class="big"><span>Prestations avec Robert (total du mois)</span><span>${money(byKey.robert)}</span></div>`;
}
$('#moisBody').addEventListener('change', e => {
  const tr = e.target.closest('tr[data-k]'), f = e.target.dataset.f; if (!tr || !f) return;
  const r = rowsOf(moisYm, tr.dataset.k).find(x => x.id === tr.dataset.id); if (!r) return;
  r[f] = e.target.value.trim(); saveDB(); updateMoisTotals();
});
$('#moisBody').addEventListener('click', e => {
  const add = e.target.dataset.add, del = e.target.closest('[data-del]');
  if (add) {
    const sc = MOIS_SECS.find(x => x.key === add), today = iso(new Date());
    moisStore(moisYm)[add].push({ id: uid(), date: today.startsWith(moisYm) ? today : moisYm + '-01', type: sc.types ? sc.types[0] : '', label: '', amount: '' });
    saveDB(); renderMois();
  } else if (del) {
    const tr = del.closest('tr'), M = moisStore(moisYm);
    M[tr.dataset.k] = M[tr.dataset.k].filter(x => x.id !== tr.dataset.id); saveDB(); renderMois();
  } else if (e.target.id === 'robFact') robertFacture();
});
// Facture du mois pour Robert : une ligne par prestation (type, description, date, prix)
function robertFacture() {
  const rows = rowsOf(moisYm, 'robert').filter(r => numOf(r.amount)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
  if (!rows.length) { toast('Aucune prestation avec un montant pour Robert ce mois-ci'); return; }
  const c = findClient('Robert');
  openFact(null, { clientName: c?.name || 'Robert', clientAddress: c?.address || '', clientTel: c?.tel || '', type: c?.type || 'particulier',
    lines: rows.map(r => ({ ref: '', title: [r.type, r.label].filter(Boolean).join(' – '), desc: r.date ? 'Le ' + frDate(r.date) : '', qty: 1, unit: 'UNITE', pu: numOf(r.amount), remise: '' })) });
}
$('#mPrev2').onclick = () => { moisYm = shiftMonth(moisYm, -1); renderMois(); };
$('#mNext2').onclick = () => { moisYm = shiftMonth(moisYm, 1); renderMois(); };
$('#mPrint').onclick = () => window.print();

/* ---------- Démarrage ---------- */
bindSiret($('#devisForm'), { siret: 'clientSiret', name: 'clientName', address: 'clientAddress' });
bindSiret($('#factForm'), { siret: 'clientSiret', name: 'clientName', address: 'clientAddress' });
bindSiret($('#lettreForm'), { siret: 'clientSiret', name: 'clientName', address: 'clientAddress' });
applyBrand(); refreshClientList(); show('devis'); initBackup();
